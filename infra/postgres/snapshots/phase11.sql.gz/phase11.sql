--
-- PostgreSQL database dump
--

\restrict 2ghpCtAY1I2BBABEYsKGr1pUG19knfBHlFCIodlPlRb3XhSHqHpo10hW7ZN5WbC

-- Dumped from database version 15.19 (Debian 15.19-0+deb12u1)
-- Dumped by pg_dump version 15.19 (Debian 15.19-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS verifier_tokens_tenant_isolation ON public.verifier_tokens;
DROP POLICY IF EXISTS proj_workflow_waits_tenant_isolation ON public.proj_workflow_waits;
DROP POLICY IF EXISTS proj_sprint_usage_tenant_isolation ON public.proj_sprint_usage;
DROP POLICY IF EXISTS proj_sprint_usage_by_agent_tenant_isolation ON public.proj_sprint_usage_by_agent;
DROP POLICY IF EXISTS proj_queue_tenant_isolation ON public.proj_queue;
DROP POLICY IF EXISTS proj_matters_tenant_isolation ON public.proj_matters;
DROP POLICY IF EXISTS proj_kpi_daily_tenant_isolation ON public.proj_kpi_daily;
DROP POLICY IF EXISTS proj_class_unlock_tenant_isolation ON public.proj_class_unlock;
DROP POLICY IF EXISTS proj_active_blocks_tenant_isolation ON public.proj_active_blocks;
DROP POLICY IF EXISTS policies_tenant_isolation ON public.policies;
DROP POLICY IF EXISTS events_tenant_isolation ON public.events;
DROP POLICY IF EXISTS clients_tenant_isolation ON public.clients;
ALTER TABLE IF EXISTS ONLY public.verifier_tokens DROP CONSTRAINT IF EXISTS verifier_tokens_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_client_links DROP CONSTRAINT IF EXISTS user_client_links_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_client_links DROP CONSTRAINT IF EXISTS user_client_links_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_brokerage_roles DROP CONSTRAINT IF EXISTS user_brokerage_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_brokerage_roles DROP CONSTRAINT IF EXISTS user_brokerage_roles_brokerage_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_brokerage_id_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_workflow_waits DROP CONSTRAINT IF EXISTS proj_workflow_waits_updated_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_sprint_usage DROP CONSTRAINT IF EXISTS proj_sprint_usage_updated_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_queue DROP CONSTRAINT IF EXISTS proj_queue_resolved_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_queue DROP CONSTRAINT IF EXISTS proj_queue_proposal_ref_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_matters DROP CONSTRAINT IF EXISTS proj_matters_updated_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_class_unlock DROP CONSTRAINT IF EXISTS proj_class_unlock_updated_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_active_blocks DROP CONSTRAINT IF EXISTS proj_active_blocks_cleared_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.proj_active_blocks DROP CONSTRAINT IF EXISTS proj_active_blocks_added_by_event_fkey;
ALTER TABLE IF EXISTS ONLY public.policies DROP CONSTRAINT IF EXISTS policies_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.magic_link_tokens DROP CONSTRAINT IF EXISTS magic_link_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.brokerages DROP CONSTRAINT IF EXISTS brokerages_tenant_id_fkey;
DROP TRIGGER IF EXISTS tenants_immutable_genesis_trg ON public.tenants;
DROP TRIGGER IF EXISTS events_no_update ON public.events;
DROP TRIGGER IF EXISTS events_no_delete ON public.events;
DROP INDEX IF EXISTS public.verifier_tokens_policy_idx;
DROP INDEX IF EXISTS public.sessions_user_idx;
DROP INDEX IF EXISTS public.proj_workflow_waits_fire_at;
DROP INDEX IF EXISTS public.proj_sprint_usage_by_agent_last_seen;
DROP INDEX IF EXISTS public.proj_queue_pending_idx;
DROP INDEX IF EXISTS public.proj_kpi_daily_recent;
DROP INDEX IF EXISTS public.proj_active_blocks_target_idx;
DROP INDEX IF EXISTS public.policies_client_idx;
DROP INDEX IF EXISTS public.magic_link_user_idx;
DROP INDEX IF EXISTS public.events_type;
DROP INDEX IF EXISTS public.events_tenant_seq;
DROP INDEX IF EXISTS public.events_tenant_idempotency;
ALTER TABLE IF EXISTS ONLY public.verifier_tokens DROP CONSTRAINT IF EXISTS verifier_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_client_links DROP CONSTRAINT IF EXISTS user_client_links_pkey;
ALTER TABLE IF EXISTS ONLY public.user_brokerage_roles DROP CONSTRAINT IF EXISTS user_brokerage_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_slug_key;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_workflow_waits DROP CONSTRAINT IF EXISTS proj_workflow_waits_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_sprint_usage DROP CONSTRAINT IF EXISTS proj_sprint_usage_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_sprint_usage_by_agent DROP CONSTRAINT IF EXISTS proj_sprint_usage_by_agent_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_queue DROP CONSTRAINT IF EXISTS proj_queue_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_matters DROP CONSTRAINT IF EXISTS proj_matters_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_kpi_daily DROP CONSTRAINT IF EXISTS proj_kpi_daily_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_class_unlock DROP CONSTRAINT IF EXISTS proj_class_unlock_pkey;
ALTER TABLE IF EXISTS ONLY public.proj_active_blocks DROP CONSTRAINT IF EXISTS proj_active_blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.policies DROP CONSTRAINT IF EXISTS policies_pkey;
ALTER TABLE IF EXISTS ONLY public.magic_link_tokens DROP CONSTRAINT IF EXISTS magic_link_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_pkey;
ALTER TABLE IF EXISTS ONLY public.brokerages DROP CONSTRAINT IF EXISTS brokerages_slug_key;
ALTER TABLE IF EXISTS ONLY public.brokerages DROP CONSTRAINT IF EXISTS brokerages_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.events ALTER COLUMN seq DROP DEFAULT;
DROP TABLE IF EXISTS public.verifier_tokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_client_links;
DROP TABLE IF EXISTS public.user_brokerage_roles;
DROP TABLE IF EXISTS public.tenants;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.proj_workflow_waits;
DROP TABLE IF EXISTS public.proj_sprint_usage_by_agent;
DROP TABLE IF EXISTS public.proj_sprint_usage;
DROP TABLE IF EXISTS public.proj_queue;
DROP TABLE IF EXISTS public.proj_matters;
DROP TABLE IF EXISTS public.proj_kpi_daily;
DROP TABLE IF EXISTS public.proj_class_unlock;
DROP TABLE IF EXISTS public.proj_active_blocks;
DROP TABLE IF EXISTS public.policies;
DROP TABLE IF EXISTS public.magic_link_tokens;
DROP SEQUENCE IF EXISTS public.events_seq_seq;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.clients;
DROP TABLE IF EXISTS public.brokerages;
DROP TABLE IF EXISTS public._migrations;
DROP FUNCTION IF EXISTS public.tenants_immutable_genesis();
DROP FUNCTION IF EXISTS public.events_deny_mutation();
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS citext;
--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: events_deny_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.events_deny_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'events table is append-only (attempted %) on event %',
    TG_OP, COALESCE(OLD.event_id::text, 'unknown');
END;
$$;


--
-- Name: tenants_immutable_genesis(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tenants_immutable_genesis() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.genesis_hash <> repeat('0', 64)
     AND NEW.genesis_hash IS DISTINCT FROM OLD.genesis_hash THEN
    RAISE EXCEPTION 'tenants.genesis_hash is immutable once set';
  END IF;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    sha256 character(64) NOT NULL
);


--
-- Name: brokerages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brokerages (
    brokerage_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    slug text NOT NULL,
    display_name text NOT NULL,
    licensee text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    client_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    display_name text NOT NULL,
    industry text NOT NULL,
    domicile text NOT NULL,
    jurisdiction_code text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    vulnerable_flag boolean DEFAULT false NOT NULL,
    CONSTRAINT clients_jurisdiction_code_check CHECK ((jurisdiction_code = ANY (ARRAY['AU'::text, 'SG'::text])))
);

ALTER TABLE ONLY public.clients FORCE ROW LEVEL SECURITY;


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    event_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    ts timestamp with time zone NOT NULL,
    actor jsonb NOT NULL,
    type text NOT NULL,
    payload jsonb NOT NULL,
    payload_jcs text NOT NULL,
    prev_hash character(64) NOT NULL,
    event_hash character(64) NOT NULL,
    idempotency_key text NOT NULL,
    mocked boolean DEFAULT false NOT NULL,
    seq bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.events FORCE ROW LEVEL SECURITY;


--
-- Name: events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_seq_seq OWNED BY public.events.seq;


--
-- Name: magic_link_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.magic_link_tokens (
    token_hash character(64) NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policies (
    policy_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    status text NOT NULL,
    product text NOT NULL,
    insurer_display text NOT NULL,
    inception timestamp with time zone NOT NULL,
    expiry timestamp with time zone NOT NULL,
    premium_amount numeric(12,2) NOT NULL,
    premium_currency text NOT NULL,
    schedule jsonb NOT NULL,
    imported_from text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT policies_status_check CHECK ((status = ANY (ARRAY['managed'::text, 'tracked'::text, 'pending'::text, 'lapsed'::text])))
);

ALTER TABLE ONLY public.policies FORCE ROW LEVEL SECURITY;


--
-- Name: proj_active_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_active_blocks (
    tenant_id uuid NOT NULL,
    block_id uuid NOT NULL,
    target_kind text NOT NULL,
    target_id text NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    cleared_at timestamp with time zone,
    cleared_reason text,
    added_by_event uuid,
    cleared_by_event uuid,
    CONSTRAINT proj_active_blocks_target_kind_check CHECK ((target_kind = ANY (ARRAY['matter'::text, 'workflow'::text])))
);

ALTER TABLE ONLY public.proj_active_blocks FORCE ROW LEVEL SECURITY;


--
-- Name: proj_class_unlock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_class_unlock (
    tenant_id uuid NOT NULL,
    class_key text NOT NULL,
    decisions_seen integer DEFAULT 0 NOT NULL,
    agreements integer DEFAULT 0 NOT NULL,
    eno_misses integer DEFAULT 0 NOT NULL,
    unlocked boolean DEFAULT false NOT NULL,
    unlocked_at timestamp with time zone,
    last_relock_at timestamp with time zone,
    last_relock_reason text,
    updated_by_event uuid
);

ALTER TABLE ONLY public.proj_class_unlock FORCE ROW LEVEL SECURITY;


--
-- Name: proj_kpi_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_kpi_daily (
    tenant_id uuid NOT NULL,
    day date NOT NULL,
    kpi_id smallint NOT NULL,
    value_scalar numeric(16,4) NOT NULL,
    value_meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    delta_prev numeric(16,4),
    spark_series numeric[],
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT proj_kpi_daily_kpi_id_check CHECK (((kpi_id >= 1) AND (kpi_id <= 12)))
);

ALTER TABLE ONLY public.proj_kpi_daily FORCE ROW LEVEL SECURITY;


--
-- Name: proj_matters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_matters (
    tenant_id uuid NOT NULL,
    matter_id uuid NOT NULL,
    client_id uuid NOT NULL,
    status text NOT NULL,
    subject text NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by_event uuid NOT NULL
);

ALTER TABLE ONLY public.proj_matters FORCE ROW LEVEL SECURITY;


--
-- Name: proj_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_queue (
    tenant_id uuid NOT NULL,
    envelope_id uuid NOT NULL,
    matter_id uuid,
    client_id uuid,
    class_key text NOT NULL,
    proposal_ref uuid NOT NULL,
    hitl_since timestamp with time zone NOT NULL,
    sla_deadline timestamp with time zone,
    gate_reason text,
    confidence numeric(4,3),
    routed_to_role text,
    resolved_at timestamp with time zone,
    resolved_by_event uuid
);

ALTER TABLE ONLY public.proj_queue FORCE ROW LEVEL SECURITY;


--
-- Name: proj_sprint_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_sprint_usage (
    tenant_id uuid NOT NULL,
    tokens_used bigint DEFAULT 0 NOT NULL,
    invocations bigint DEFAULT 0 NOT NULL,
    last_alert_pct integer DEFAULT 0 NOT NULL,
    updated_by_event uuid
);

ALTER TABLE ONLY public.proj_sprint_usage FORCE ROW LEVEL SECURITY;


--
-- Name: proj_sprint_usage_by_agent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_sprint_usage_by_agent (
    tenant_id uuid NOT NULL,
    agent_name text NOT NULL,
    tokens_used_input bigint DEFAULT 0 NOT NULL,
    tokens_used_output bigint DEFAULT 0 NOT NULL,
    invocations integer DEFAULT 0 NOT NULL,
    first_seen timestamp with time zone DEFAULT now() NOT NULL,
    last_seen timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.proj_sprint_usage_by_agent FORCE ROW LEVEL SECURITY;


--
-- Name: proj_workflow_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proj_workflow_waits (
    tenant_id uuid NOT NULL,
    workflow_id text NOT NULL,
    step text NOT NULL,
    resume_predicate jsonb NOT NULL,
    fire_at timestamp with time zone,
    timeout_at timestamp with time zone,
    resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp with time zone,
    updated_by_event uuid
);

ALTER TABLE ONLY public.proj_workflow_waits FORCE ROW LEVEL SECURITY;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    session_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    brokerage_id uuid,
    client_id uuid,
    active_role text NOT NULL,
    mfa_verified boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    client_prefs jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    tenant_id uuid NOT NULL,
    slug text NOT NULL,
    display_name text NOT NULL,
    genesis_hash character(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_brokerage_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_brokerage_roles (
    user_id uuid NOT NULL,
    brokerage_id uuid NOT NULL,
    role text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_brokerage_roles_role_check CHECK ((role = ANY (ARRAY['principal'::text, 'deputy'::text, 'ae'::text, 'accounts'::text, 'compliance'::text, 'pod_lead'::text, 'account_manager'::text, 'claims_manager'::text, 'tenant_admin'::text, 'auditor'::text])))
);


--
-- Name: user_client_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_client_links (
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_client_links_role_check CHECK ((role = ANY (ARRAY['client_owner'::text, 'client_finance'::text])))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id uuid NOT NULL,
    email public.citext NOT NULL,
    display_name text NOT NULL,
    kind text NOT NULL,
    password_hash text,
    mfa_secret text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_kind_check CHECK ((kind = ANY (ARRAY['operator'::text, 'client'::text])))
);


--
-- Name: verifier_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verifier_tokens (
    token_hash character(64) NOT NULL,
    tenant_id uuid NOT NULL,
    policy_id uuid NOT NULL,
    certificate_id uuid NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    rate_limit_count integer DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.verifier_tokens FORCE ROW LEVEL SECURITY;


--
-- Name: events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events ALTER COLUMN seq SET DEFAULT nextval('public.events_seq_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, applied_at, sha256) FROM stdin;
001_tenants_and_events.sql	2026-09-12 12:06:46.817204+00	1b5888f55ec5830632027f6bc0bb3d5a1f9903ee70e252de27b6481bedd19b3c
002_projection_matters.sql	2026-09-12 12:06:46.845462+00	cf79cd468334bd9ecbfe387f271c0bf47234e4ff8c1e5ac26de3c79af30a4ee6
003_gate_and_workflow.sql	2026-09-12 12:18:52.662662+00	059bf15f3dacfd3be8551f0e8bb86e11188cbb9dd29fedf2843081a03b49ad32
004_sprint_usage.sql	2026-09-12 12:59:47.853908+00	8ac59a85783f1bec29bc9a3297802bb096620c57b28f076968cd73c950da1bb6
005_auth.sql	2026-09-12 13:16:13.506803+00	528b73db80e530c8740aff3e3f5bb693d0a3b1af8caba0ac928c8aafe303debe
006_policies_and_clients.sql	2026-09-12 13:25:05.171655+00	36d1003f50f62805915b7bf2e92a4b2a5209ba37a1f479ae45922205bc328385
007_operator_projections.sql	2026-09-12 14:06:59.069042+00	4cc86e5fa2f5099da17257f2532a9a66304451e75ea56f07b7cec30def8c81f2
008_agent_usage.sql	2026-09-13 03:07:55.32812+00	c87c28a100ab22bca2c2a8ffbd45cbe2ebbde4dfba0ce1a19aeb910f2878ffd4
009_client_vulnerable_flag.sql	2026-09-13 03:58:31.244469+00	a869cfeff221527f11f6b0240a0402f2c39bd58afd73bf56c4950f93402f09f6
010_verifier_tokens.sql	2026-09-13 03:58:31.246873+00	0100f05fa06504a83295ac4a135507ca4e8adf81491a435edc510006d52e3278
011_verifier_tokens_rls_fix.sql	2026-09-13 04:26:44.421695+00	fa8e1688117a76714a9cd28e2f6a16e87ccc09c85c4e907fcb481673c3e9527f
\.


--
-- Data for Name: brokerages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brokerages (brokerage_id, tenant_id, slug, display_name, licensee, created_at) FROM stdin;
db12fced-8abd-4542-a379-152aa5164e8d	e73e7029-da66-4659-9ac8-845f22b1f8a5	burmac-brokerage	BurMac Insurance Brokers Pty Ltd	BurMac Financial Services Pty Ltd (ACN 000-000-000)	2026-09-13 04:15:19.403153+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (client_id, tenant_id, display_name, industry, domicile, jurisdiction_code, created_at, vulnerable_flag) FROM stdin;
00000000-0000-4000-8000-000000000001	e73e7029-da66-4659-9ac8-845f22b1f8a5	Harbour Marine Services Pty Ltd	marine_services	Sydney, AU	AU	2026-09-13 04:15:19.695433+00	f
00000000-0000-4000-8000-000000000003	e73e7029-da66-4659-9ac8-845f22b1f8a5	Kelp Shipping Co. Pty Ltd	shipping	Melbourne, AU	AU	2026-09-13 04:15:19.756843+00	t
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (event_id, tenant_id, ts, actor, type, payload, payload_jcs, prev_hash, event_hash, idempotency_key, mocked, seq, created_at) FROM stdin;
174f4e1d-326b-45a5-9e2e-2d1c114b001f	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.39942+00	{"id": "trail", "kind": "system", "name": "trAIl"}	TenantGenesis	{"slug": "burmac", "display_name": "BurMac Insurance Brokers"}	{"display_name":"BurMac Insurance Brokers","slug":"burmac"}	0000000000000000000000000000000000000000000000000000000000000000	de03f43f66c387acb8a73a804f58434e0fffb7fe8a7c493e9c35604221719f1a	genesis:burmac	f	1	2026-09-13 04:15:19.398094+00
84d0d705-f066-44ef-8895-70f08c778e3b	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.69316+00	{"id": "seed", "kind": "system", "name": "phase5-seed"}	LicenseeCreated	{"fictional": true, "licensee_abn": "FICTIONAL_LICENSEE_ABN_0000", "licensee_name": "Fictional Licensee Pty Ltd"}	{"fictional":true,"licensee_abn":"FICTIONAL_LICENSEE_ABN_0000","licensee_name":"Fictional Licensee Pty Ltd"}	de03f43f66c387acb8a73a804f58434e0fffb7fe8a7c493e9c35604221719f1a	111953af08bc3eea3c1b54cb6a02346531f10ed0ae24a8b6ec5476db3740f392	seed:licensee:FICTIONAL_LICENSEE_ABN_0000	f	2	2026-09-13 04:15:19.692921+00
f4a76676-f0ab-4a04-a486-c0b429bcbd8a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.694444+00	{"id": "seed", "kind": "system", "name": "phase5-seed"}	BrokerageCreated	{"fictional": true, "brokerage_id": "db12fced-8abd-4542-a379-152aa5164e8d", "licensee_abn": "FICTIONAL_LICENSEE_ABN_0000"}	{"brokerage_id":"db12fced-8abd-4542-a379-152aa5164e8d","fictional":true,"licensee_abn":"FICTIONAL_LICENSEE_ABN_0000"}	111953af08bc3eea3c1b54cb6a02346531f10ed0ae24a8b6ec5476db3740f392	68ada3a3fc21f48b34dacfc96e797b48d7bcf20df88ad94a0365a6d916cedb42	seed:brokerage:db12fced-8abd-4542-a379-152aa5164e8d	f	3	2026-09-13 04:15:19.694263+00
99f8d41d-c229-41f6-b1db-b1bf88d29306	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.69693+00	{"id": "seed", "kind": "system", "name": "phase5-seed"}	ClientEntityCreated	{"domicile": "Sydney, AU", "industry": "marine_services", "client_id": "00000000-0000-4000-8000-000000000001", "fictional": true, "display_name": "Harbour Marine Services Pty Ltd", "jurisdiction_code": "AU"}	{"client_id":"00000000-0000-4000-8000-000000000001","display_name":"Harbour Marine Services Pty Ltd","domicile":"Sydney, AU","fictional":true,"industry":"marine_services","jurisdiction_code":"AU"}	68ada3a3fc21f48b34dacfc96e797b48d7bcf20df88ad94a0365a6d916cedb42	0e9fbc4fc24b938a5858b6e791eb487d2836eb7e10dc4cb7dd9068bd8a116380	seed:client:00000000-0000-4000-8000-000000000001	f	4	2026-09-13 04:15:19.696747+00
d88815e0-8009-4774-88d5-4355b2c6e060	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.699408+00	{"id": "seed", "kind": "system", "name": "phase5-seed"}	PolicyCreated	{"mocked": true, "status": "managed", "product": "Marine Liability", "schedule": {"excess": {"currency": "AUD", "any_one_occurrence": 25000}, "cover_types": [{"type": "Public Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}, {"type": "Products Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}], "territorial_limits": "Worldwide excl. USA/Canada"}, "client_id": "00000000-0000-4000-8000-000000000001", "fictional": true, "policy_id": "00000000-0000-4000-8000-000000000101", "premium_amount": 8500.0, "insurer_display": "Fictional Carrier A", "premium_currency": "AUD"}	{"client_id":"00000000-0000-4000-8000-000000000001","fictional":true,"insurer_display":"Fictional Carrier A","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","premium_amount":8500,"premium_currency":"AUD","product":"Marine Liability","schedule":{"cover_types":[{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Public Liability"},{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Products Liability"}],"excess":{"any_one_occurrence":25000,"currency":"AUD"},"territorial_limits":"Worldwide excl. USA/Canada"},"status":"managed"}	0e9fbc4fc24b938a5858b6e791eb487d2836eb7e10dc4cb7dd9068bd8a116380	f21bde452d373c79ef423c6231c9afff22ec47c8a7be9a80cbaa4dc5fe702191	seed:policy_created:00000000-0000-4000-8000-000000000101	f	5	2026-09-13 04:15:19.699224+00
587eedcc-f441-43ec-a54e-8dae941283c6	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.701648+00	{"id": "seed", "kind": "system", "name": "phase5-seed"}	PolicyCreated	{"mocked": true, "status": "tracked", "product": "Cyber", "schedule": {"excess": {"currency": "AUD", "any_one_claim": 10000}, "cover_types": [{"type": "Cyber Liability", "currency": "AUD", "aggregate": 2000000, "limit_any_one": 2000000}], "territorial_limits": "Australia only"}, "client_id": "00000000-0000-4000-8000-000000000001", "fictional": true, "policy_id": "00000000-0000-4000-8000-000000000102", "imported_from": "manual_entry_burmac", "premium_amount": 2200.0, "insurer_display": "Fictional Carrier B", "premium_currency": "AUD"}	{"client_id":"00000000-0000-4000-8000-000000000001","fictional":true,"imported_from":"manual_entry_burmac","insurer_display":"Fictional Carrier B","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000102","premium_amount":2200,"premium_currency":"AUD","product":"Cyber","schedule":{"cover_types":[{"aggregate":2000000,"currency":"AUD","limit_any_one":2000000,"type":"Cyber Liability"}],"excess":{"any_one_claim":10000,"currency":"AUD"},"territorial_limits":"Australia only"},"status":"tracked"}	f21bde452d373c79ef423c6231c9afff22ec47c8a7be9a80cbaa4dc5fe702191	7378fc004f5b56c53f4490dfbe1f5f7791e2de2c64dbca3e0b7b801f8ce83597	seed:policy_created:00000000-0000-4000-8000-000000000102	f	6	2026-09-13 04:15:19.701456+00
ebe6142e-2862-4489-a04b-ffa749642d14	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.705915+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "reject", "class_key": "comms_service", "confidence": {"scalar": 0.712, "components": {"completeness": 0.756, "class_agreement": 0.724, "schema_validity": 0.732, "citation_existence": 0.712}}, "envelope_id": "2b8de58c-83be-5c66-b80d-2b130a27744f"}	{"class_key":"comms_service","confidence":{"components":{"citation_existence":0.712,"class_agreement":0.724,"completeness":0.756,"schema_validity":0.732},"scalar":0.712},"decision":"reject","envelope_id":"2b8de58c-83be-5c66-b80d-2b130a27744f","role":"principal","user_id":"principal"}	7378fc004f5b56c53f4490dfbe1f5f7791e2de2c64dbca3e0b7b801f8ce83597	844bfe240f65182a9739b0c2d2953f98c39469ea2da10e90dcf0ed7fedee5022	appr:2b8de58c-83be-5c66-b80d-2b130a27744f:principal:reject	f	7	2026-09-13 04:15:19.705769+00
ed070f12-34e8-417d-b91e-14e58794d504	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.707249+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "approve", "class_key": "comms_service", "confidence": {"scalar": 0.94, "components": {"completeness": 0.948, "class_agreement": 0.972, "schema_validity": 0.972, "citation_existence": 0.94}}, "envelope_id": "573a1085-e49c-5cbc-a973-50d618d3daf9"}	{"class_key":"comms_service","confidence":{"components":{"citation_existence":0.94,"class_agreement":0.972,"completeness":0.948,"schema_validity":0.972},"scalar":0.94},"decision":"approve","envelope_id":"573a1085-e49c-5cbc-a973-50d618d3daf9","role":"principal","user_id":"principal"}	844bfe240f65182a9739b0c2d2953f98c39469ea2da10e90dcf0ed7fedee5022	d2cb6ba6f489ef0a7156dea3f85f4929726662a384a890629d325f8dd4a6dae0	appr:573a1085-e49c-5cbc-a973-50d618d3daf9:principal:approve	f	8	2026-09-13 04:15:19.707103+00
9a358d14-91f6-4e30-b210-f4bab4c2981f	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:40.74998+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationCompleted	{"outcome": "ok", "agent_name": "intake", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"agent_name":"intake","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","outcome":"ok"}	a82fb9503161507bd978c0351d5454b9c3e831bba42570505964bf3c9ffa6784	628451981b27915b9d9e9cb6386d1bcf2f844c2898b8d33c08e2c77f58bd174e	aginv:done:25516a4e-156f-4e01-a3c7-dd714d970113:intake	f	54	2026-09-13 04:15:40.749824+00
5284c22a-59e6-45b4-b608-13b747784dcc	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.708367+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "reject", "class_key": "submit_to_market", "confidence": {"scalar": 0.751, "components": {"completeness": 0.772, "class_agreement": 0.783, "schema_validity": 0.778, "citation_existence": 0.751}}, "envelope_id": "31344167-3e62-5c2a-81de-ab683834e96e"}	{"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.751,"class_agreement":0.783,"completeness":0.772,"schema_validity":0.778},"scalar":0.751},"decision":"reject","envelope_id":"31344167-3e62-5c2a-81de-ab683834e96e","role":"compliance","user_id":"compliance"}	d2cb6ba6f489ef0a7156dea3f85f4929726662a384a890629d325f8dd4a6dae0	be8d07da2a4a7d9bdd3a7b52b14b09e055b433ee6b0c2a44429299b63d2b80c1	appr:31344167-3e62-5c2a-81de-ab683834e96e:compliance:reject	f	9	2026-09-13 04:15:19.70823+00
ed89a9ed-36ad-4229-80e0-20c46d722b16	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.709669+00	{"id": "accounts-b", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-b", "decision": "approve", "class_key": "submit_to_market", "confidence": {"scalar": 0.963, "components": {"completeness": 0.973, "class_agreement": 0.963, "schema_validity": 0.97, "citation_existence": 0.967}}, "envelope_id": "dbfab3f0-88bb-5608-8cb7-b2db40511005"}	{"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.967,"class_agreement":0.963,"completeness":0.973,"schema_validity":0.97},"scalar":0.963},"decision":"approve","envelope_id":"dbfab3f0-88bb-5608-8cb7-b2db40511005","role":"accounts","user_id":"accounts-b"}	be8d07da2a4a7d9bdd3a7b52b14b09e055b433ee6b0c2a44429299b63d2b80c1	40fcbf2e2529c1c2fcb83dfc2ad3c1944f5a76a461c3f6f9ad8c24941c6af021	appr:dbfab3f0-88bb-5608-8cb7-b2db40511005:accounts-b:approve	f	10	2026-09-13 04:15:19.70953+00
9717b24c-a133-46f2-abb9-e38bd6a582f0	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.711003+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "approve", "class_key": "submit_to_market", "confidence": {"scalar": 0.889, "components": {"completeness": 0.943, "class_agreement": 0.935, "schema_validity": 0.946, "citation_existence": 0.889}}, "envelope_id": "90207b26-68d0-571b-a902-66f1a5034def"}	{"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.889,"class_agreement":0.935,"completeness":0.943,"schema_validity":0.946},"scalar":0.889},"decision":"approve","envelope_id":"90207b26-68d0-571b-a902-66f1a5034def","role":"principal","user_id":"principal"}	40fcbf2e2529c1c2fcb83dfc2ad3c1944f5a76a461c3f6f9ad8c24941c6af021	9bb450489a2db0093ca7b20fdf79c92958ccb157f806107c3e487ebe035ab4f0	appr:90207b26-68d0-571b-a902-66f1a5034def:principal:approve	f	11	2026-09-13 04:15:19.710863+00
789deb06-96ca-4ad7-b85a-0e81a099bfb9	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.712045+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "reject", "class_key": "request_info", "confidence": {"scalar": 0.779, "components": {"completeness": 0.823, "class_agreement": 0.795, "schema_validity": 0.822, "citation_existence": 0.779}}, "envelope_id": "c5f45d5f-aaad-540f-bcfb-c4640221b8ac"}	{"class_key":"request_info","confidence":{"components":{"citation_existence":0.779,"class_agreement":0.795,"completeness":0.823,"schema_validity":0.822},"scalar":0.779},"decision":"reject","envelope_id":"c5f45d5f-aaad-540f-bcfb-c4640221b8ac","role":"principal","user_id":"principal"}	9bb450489a2db0093ca7b20fdf79c92958ccb157f806107c3e487ebe035ab4f0	abe8439abb81c066396cf838d049dafd8cdfa44af9214fa76be3d73cfc2e6f88	appr:c5f45d5f-aaad-540f-bcfb-c4640221b8ac:principal:reject	f	12	2026-09-13 04:15:19.711907+00
167af617-e068-4c44-9332-0aee2a66aafa	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.71317+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "comms_service", "confidence": {"scalar": 0.89, "components": {"completeness": 0.908, "class_agreement": 0.89, "schema_validity": 0.921, "citation_existence": 0.94}}, "envelope_id": "705a4fc0-ca2b-5a6b-9863-d48a5186c2e5"}	{"class_key":"comms_service","confidence":{"components":{"citation_existence":0.94,"class_agreement":0.89,"completeness":0.908,"schema_validity":0.921},"scalar":0.89},"decision":"approve","envelope_id":"705a4fc0-ca2b-5a6b-9863-d48a5186c2e5","role":"accounts","user_id":"accounts-a"}	abe8439abb81c066396cf838d049dafd8cdfa44af9214fa76be3d73cfc2e6f88	fa224186c4bd3089a4fde5f871697b16548445fb20fe5d7c320c369f7e0621b3	appr:705a4fc0-ca2b-5a6b-9863-d48a5186c2e5:accounts-a:approve	f	13	2026-09-13 04:15:19.713035+00
1958dd13-d46c-48a4-9e81-8cfe2f975ceb	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.714308+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "request_info", "confidence": {"scalar": 0.87, "components": {"completeness": 0.902, "class_agreement": 0.927, "schema_validity": 0.91, "citation_existence": 0.87}}, "envelope_id": "12c941a4-5da6-5f1d-9b5a-c569275961db"}	{"class_key":"request_info","confidence":{"components":{"citation_existence":0.87,"class_agreement":0.927,"completeness":0.902,"schema_validity":0.91},"scalar":0.87},"decision":"approve","envelope_id":"12c941a4-5da6-5f1d-9b5a-c569275961db","role":"accounts","user_id":"accounts-a"}	fa224186c4bd3089a4fde5f871697b16548445fb20fe5d7c320c369f7e0621b3	bc3f3c316381434c40685f919517325f460f1c77f96d48602f14a9855bb0e730	appr:12c941a4-5da6-5f1d-9b5a-c569275961db:accounts-a:approve	f	14	2026-09-13 04:15:19.714165+00
716d2f25-20f3-450e-9e18-88f624969a9a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.715381+00	{"id": "accounts-b", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-b", "decision": "approve", "class_key": "structure_risk", "confidence": {"scalar": 0.968, "components": {"completeness": 0.969, "class_agreement": 0.973, "schema_validity": 0.968, "citation_existence": 0.994}}, "envelope_id": "e55a5d8b-fc43-5737-b2ed-f42bd3f98940"}	{"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.994,"class_agreement":0.973,"completeness":0.969,"schema_validity":0.968},"scalar":0.968},"decision":"approve","envelope_id":"e55a5d8b-fc43-5737-b2ed-f42bd3f98940","role":"accounts","user_id":"accounts-b"}	bc3f3c316381434c40685f919517325f460f1c77f96d48602f14a9855bb0e730	7a1659c7b52b6a2a0dbfa63d4da43ce7f2d72a85cbb5b57518e678dee570db57	appr:e55a5d8b-fc43-5737-b2ed-f42bd3f98940:accounts-b:approve	f	15	2026-09-13 04:15:19.715243+00
0a7a1ea0-853c-47df-98b1-617d8890ce60	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.716442+00	{"id": "accounts-b", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-b", "decision": "reject", "class_key": "endorsement_standard", "confidence": {"scalar": 0.724, "components": {"completeness": 0.724, "class_agreement": 0.76, "schema_validity": 0.738, "citation_existence": 0.784}}, "envelope_id": "61bf0fb8-7f8b-5a82-9d94-f07c37024c2e"}	{"class_key":"endorsement_standard","confidence":{"components":{"citation_existence":0.784,"class_agreement":0.76,"completeness":0.724,"schema_validity":0.738},"scalar":0.724},"decision":"reject","envelope_id":"61bf0fb8-7f8b-5a82-9d94-f07c37024c2e","role":"accounts","user_id":"accounts-b"}	7a1659c7b52b6a2a0dbfa63d4da43ce7f2d72a85cbb5b57518e678dee570db57	5437f9d04d665f0ecd789a51e4b2e7b3c0f1d3e140d17c1e60fccbdea64de673	appr:61bf0fb8-7f8b-5a82-9d94-f07c37024c2e:accounts-b:reject	f	16	2026-09-13 04:15:19.716309+00
b408816b-0911-4bf1-b591-124b4db92ebb	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.717506+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "reject", "class_key": "structure_risk", "confidence": {"scalar": 0.751, "components": {"completeness": 0.769, "class_agreement": 0.777, "schema_validity": 0.751, "citation_existence": 0.8}}, "envelope_id": "cc994d10-5c2e-543f-9b04-4d26c77fa0ce"}	{"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.8,"class_agreement":0.777,"completeness":0.769,"schema_validity":0.751},"scalar":0.751},"decision":"reject","envelope_id":"cc994d10-5c2e-543f-9b04-4d26c77fa0ce","role":"compliance","user_id":"compliance"}	5437f9d04d665f0ecd789a51e4b2e7b3c0f1d3e140d17c1e60fccbdea64de673	4f96cc69dd6f4ed1fae373fe624136e9bcc1bfbd48a3ede089c3d0b6fdd19db4	appr:cc994d10-5c2e-543f-9b04-4d26c77fa0ce:compliance:reject	f	17	2026-09-13 04:15:19.717375+00
038b92d3-b23e-4a3b-a059-994c423eea75	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.718561+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "submit_to_market", "confidence": {"scalar": 0.901, "components": {"completeness": 0.949, "class_agreement": 0.901, "schema_validity": 0.921, "citation_existence": 0.924}}, "envelope_id": "bf0c5689-4630-595a-9a92-02599de7423e"}	{"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.924,"class_agreement":0.901,"completeness":0.949,"schema_validity":0.921},"scalar":0.901},"decision":"approve","envelope_id":"bf0c5689-4630-595a-9a92-02599de7423e","role":"accounts","user_id":"accounts-a"}	4f96cc69dd6f4ed1fae373fe624136e9bcc1bfbd48a3ede089c3d0b6fdd19db4	11ce6dc3a6e37529318c3c903c063a0a1fe5f07133df78f4e92190067ca66bef	appr:bf0c5689-4630-595a-9a92-02599de7423e:accounts-a:approve	f	18	2026-09-13 04:15:19.718408+00
e1ff8e6d-2cf2-486f-bf57-cfb97290a4b1	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.719574+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "reject", "class_key": "structure_risk", "confidence": {"scalar": 0.704, "components": {"completeness": 0.704, "class_agreement": 0.75, "schema_validity": 0.714, "citation_existence": 0.734}}, "envelope_id": "dcec3fce-cb40-5a69-b76a-f9bed6bc4433"}	{"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.734,"class_agreement":0.75,"completeness":0.704,"schema_validity":0.714},"scalar":0.704},"decision":"reject","envelope_id":"dcec3fce-cb40-5a69-b76a-f9bed6bc4433","role":"compliance","user_id":"compliance"}	11ce6dc3a6e37529318c3c903c063a0a1fe5f07133df78f4e92190067ca66bef	56ab51bfd46baab90b4fb3c8849b4921c1936a325b8bd364eeeee2ecfa4f338c	appr:dcec3fce-cb40-5a69-b76a-f9bed6bc4433:compliance:reject	f	19	2026-09-13 04:15:19.719431+00
ef3409b0-9810-46b6-b117-ba937fe41794	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.720551+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "approve", "class_key": "endorsement_standard", "confidence": {"scalar": 0.953, "components": {"completeness": 0.953, "class_agreement": 0.964, "schema_validity": 0.963, "citation_existence": 0.993}}, "envelope_id": "50f85cb9-4670-5f07-8637-66d27ab6c31a"}	{"class_key":"endorsement_standard","confidence":{"components":{"citation_existence":0.993,"class_agreement":0.964,"completeness":0.953,"schema_validity":0.963},"scalar":0.953},"decision":"approve","envelope_id":"50f85cb9-4670-5f07-8637-66d27ab6c31a","role":"principal","user_id":"principal"}	56ab51bfd46baab90b4fb3c8849b4921c1936a325b8bd364eeeee2ecfa4f338c	c30a9e070e47533ff8add469ce6b293bc661be3b121b37b219324538fe58112c	appr:50f85cb9-4670-5f07-8637-66d27ab6c31a:principal:approve	f	20	2026-09-13 04:15:19.720419+00
bc0146c8-ba8e-4352-91d8-eb9cb146af65	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.721532+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "approve", "class_key": "endorsement_standard", "confidence": {"scalar": 0.95, "components": {"completeness": 0.95, "class_agreement": 0.995, "schema_validity": 0.971, "citation_existence": 0.954}}, "envelope_id": "15a990e9-2c1d-5d70-8404-8bec7097807d"}	{"class_key":"endorsement_standard","confidence":{"components":{"citation_existence":0.954,"class_agreement":0.995,"completeness":0.95,"schema_validity":0.971},"scalar":0.95},"decision":"approve","envelope_id":"15a990e9-2c1d-5d70-8404-8bec7097807d","role":"compliance","user_id":"compliance"}	c30a9e070e47533ff8add469ce6b293bc661be3b121b37b219324538fe58112c	3454ae005c0931282920c80dcb86de4c1ad261bc562c0e2fb3fc10de26d6abf5	appr:15a990e9-2c1d-5d70-8404-8bec7097807d:compliance:approve	f	21	2026-09-13 04:15:19.721399+00
f44cae12-6cc2-4f10-98af-3be9d79c857a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.722523+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "structure_risk", "confidence": {"scalar": 0.875, "components": {"completeness": 0.883, "class_agreement": 0.875, "schema_validity": 0.893, "citation_existence": 0.91}}, "envelope_id": "63e4d6a4-6ef4-51bd-9eba-940a3ebe1921"}	{"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.91,"class_agreement":0.875,"completeness":0.883,"schema_validity":0.893},"scalar":0.875},"decision":"approve","envelope_id":"63e4d6a4-6ef4-51bd-9eba-940a3ebe1921","role":"accounts","user_id":"accounts-a"}	3454ae005c0931282920c80dcb86de4c1ad261bc562c0e2fb3fc10de26d6abf5	8a9cbf975b35d6f157be89814113a210f0e8673eff686b2406b2c75c5539ba38	appr:63e4d6a4-6ef4-51bd-9eba-940a3ebe1921:accounts-a:approve	f	22	2026-09-13 04:15:19.722379+00
e8e711d3-1255-47be-aa23-14c62dd41d56	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.723467+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "approve", "class_key": "submit_to_market", "confidence": {"scalar": 0.937, "components": {"completeness": 0.937, "class_agreement": 0.937, "schema_validity": 0.977, "citation_existence": 0.99}}, "envelope_id": "ceedf714-c286-5312-893b-99333620c324"}	{"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.99,"class_agreement":0.937,"completeness":0.937,"schema_validity":0.977},"scalar":0.937},"decision":"approve","envelope_id":"ceedf714-c286-5312-893b-99333620c324","role":"principal","user_id":"principal"}	8a9cbf975b35d6f157be89814113a210f0e8673eff686b2406b2c75c5539ba38	eeab5b3a1ebfc7766ddae916ce0537dd900107256fa258fe81ba05b694e6b609	appr:ceedf714-c286-5312-893b-99333620c324:principal:approve	f	23	2026-09-13 04:15:19.723328+00
0ee42068-b270-45ae-b522-548050ef58a5	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.72453+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "renewal_pack_unchanged", "confidence": {"scalar": 0.941, "components": {"completeness": 0.968, "class_agreement": 0.964, "schema_validity": 0.941, "citation_existence": 0.96}}, "envelope_id": "d22c1f92-5cd6-542c-a412-e609346f720f"}	{"class_key":"renewal_pack_unchanged","confidence":{"components":{"citation_existence":0.96,"class_agreement":0.964,"completeness":0.968,"schema_validity":0.941},"scalar":0.941},"decision":"approve","envelope_id":"d22c1f92-5cd6-542c-a412-e609346f720f","role":"accounts","user_id":"accounts-a"}	eeab5b3a1ebfc7766ddae916ce0537dd900107256fa258fe81ba05b694e6b609	fa3925102cf0a2872c020bb17ba62686eb527c6f5600c32e75d00a72b8e19cc6	appr:d22c1f92-5cd6-542c-a412-e609346f720f:accounts-a:approve	f	24	2026-09-13 04:15:19.724391+00
0c319aa4-00b9-42cc-9c77-41dfa53e8bd1	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.725632+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "approve", "class_key": "submit_to_market", "confidence": {"scalar": 0.862, "components": {"completeness": 0.862, "class_agreement": 0.891, "schema_validity": 0.865, "citation_existence": 0.907}}, "envelope_id": "05e534dd-8407-5ba4-bd70-2dec8e37ec5a"}	{"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.907,"class_agreement":0.891,"completeness":0.862,"schema_validity":0.865},"scalar":0.862},"decision":"approve","envelope_id":"05e534dd-8407-5ba4-bd70-2dec8e37ec5a","role":"principal","user_id":"principal"}	fa3925102cf0a2872c020bb17ba62686eb527c6f5600c32e75d00a72b8e19cc6	5fc26af1c7c833d7db96c7dc5f92f69d840d836355655a0352e699251cd4488b	appr:05e534dd-8407-5ba4-bd70-2dec8e37ec5a:principal:approve	f	25	2026-09-13 04:15:19.725481+00
31fd4464-14f3-4a8c-918b-b78fca0dd426	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.726719+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "reject", "class_key": "claim_admin", "confidence": {"scalar": 0.767, "components": {"completeness": 0.767, "class_agreement": 0.779, "schema_validity": 0.772, "citation_existence": 0.778}}, "envelope_id": "d0a028aa-1587-5bcc-9a22-e03e57bf69ea"}	{"class_key":"claim_admin","confidence":{"components":{"citation_existence":0.778,"class_agreement":0.779,"completeness":0.767,"schema_validity":0.772},"scalar":0.767},"decision":"reject","envelope_id":"d0a028aa-1587-5bcc-9a22-e03e57bf69ea","role":"compliance","user_id":"compliance"}	5fc26af1c7c833d7db96c7dc5f92f69d840d836355655a0352e699251cd4488b	90b3ea08c5c62b958fed6def5c3b7dbd6bc9a97f555b8755b312f58e12eb7479	appr:d0a028aa-1587-5bcc-9a22-e03e57bf69ea:compliance:reject	f	26	2026-09-13 04:15:19.726585+00
1ddecc1f-a6d2-419a-b870-2047e02bc935	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.72774+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "approve", "class_key": "request_info", "confidence": {"scalar": 0.939, "components": {"completeness": 0.94, "class_agreement": 0.944, "schema_validity": 0.939, "citation_existence": 0.945}}, "envelope_id": "d4a398da-d738-5fc3-b2e8-041a83aa569b"}	{"class_key":"request_info","confidence":{"components":{"citation_existence":0.945,"class_agreement":0.944,"completeness":0.94,"schema_validity":0.939},"scalar":0.939},"decision":"approve","envelope_id":"d4a398da-d738-5fc3-b2e8-041a83aa569b","role":"compliance","user_id":"compliance"}	90b3ea08c5c62b958fed6def5c3b7dbd6bc9a97f555b8755b312f58e12eb7479	e220e048d70c52099fee5cca1f8ecb640596b2297c1a81fb6cc3381e1f9b3227	appr:d4a398da-d738-5fc3-b2e8-041a83aa569b:compliance:approve	f	27	2026-09-13 04:15:19.72761+00
fa89c6d4-09b6-485d-ae7a-68e6f7bcf89e	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.728703+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "reject", "class_key": "claim_admin", "confidence": {"scalar": 0.788, "components": {"completeness": 0.788, "class_agreement": 0.795, "schema_validity": 0.822, "citation_existence": 0.837}}, "envelope_id": "00104d57-6a3a-5c4d-a5a3-a9943008b9e3"}	{"class_key":"claim_admin","confidence":{"components":{"citation_existence":0.837,"class_agreement":0.795,"completeness":0.788,"schema_validity":0.822},"scalar":0.788},"decision":"reject","envelope_id":"00104d57-6a3a-5c4d-a5a3-a9943008b9e3","role":"compliance","user_id":"compliance"}	e220e048d70c52099fee5cca1f8ecb640596b2297c1a81fb6cc3381e1f9b3227	06fce3e2e6e6ababb3a89d2569eb3bc704fbe158d697217e2b1c1e7c88faca25	appr:00104d57-6a3a-5c4d-a5a3-a9943008b9e3:compliance:reject	f	28	2026-09-13 04:15:19.728574+00
84ca90e7-cc04-4fe0-a75c-3bf1bbd08ebc	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.729773+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "reject", "class_key": "request_info", "confidence": {"scalar": 0.737, "components": {"completeness": 0.751, "class_agreement": 0.758, "schema_validity": 0.737, "citation_existence": 0.782}}, "envelope_id": "b31c6c75-af29-549e-bd99-23d35db526e9"}	{"class_key":"request_info","confidence":{"components":{"citation_existence":0.782,"class_agreement":0.758,"completeness":0.751,"schema_validity":0.737},"scalar":0.737},"decision":"reject","envelope_id":"b31c6c75-af29-549e-bd99-23d35db526e9","role":"accounts","user_id":"accounts-a"}	06fce3e2e6e6ababb3a89d2569eb3bc704fbe158d697217e2b1c1e7c88faca25	ab1a0b19ae193ffdddd48c70f35b12031ea24687eb46f686b6f2ab583555b28d	appr:b31c6c75-af29-549e-bd99-23d35db526e9:accounts-a:reject	f	29	2026-09-13 04:15:19.729646+00
fd150c2e-6bac-444e-a346-2682f707043a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.730812+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "claim_admin", "confidence": {"scalar": 0.875, "components": {"completeness": 0.89, "class_agreement": 0.875, "schema_validity": 0.878, "citation_existence": 0.925}}, "envelope_id": "3b92d506-376c-569e-9ea1-681bfb18b518"}	{"class_key":"claim_admin","confidence":{"components":{"citation_existence":0.925,"class_agreement":0.875,"completeness":0.89,"schema_validity":0.878},"scalar":0.875},"decision":"approve","envelope_id":"3b92d506-376c-569e-9ea1-681bfb18b518","role":"accounts","user_id":"accounts-a"}	ab1a0b19ae193ffdddd48c70f35b12031ea24687eb46f686b6f2ab583555b28d	3c65d9b941c8887ed21b438e7766abccb51d724afe41a6eeb0e5c19f2f8270e4	appr:3b92d506-376c-569e-9ea1-681bfb18b518:accounts-a:approve	f	30	2026-09-13 04:15:19.730687+00
5fab00b3-14c6-4616-b2ab-dd8a336e8075	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.731751+00	{"id": "accounts-b", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-b", "decision": "approve", "class_key": "comms_service", "confidence": {"scalar": 0.963, "components": {"completeness": 0.969, "class_agreement": 0.963, "schema_validity": 0.97, "citation_existence": 0.975}}, "envelope_id": "e5839f9d-7ece-56ec-b8b3-97eeb43e89bd"}	{"class_key":"comms_service","confidence":{"components":{"citation_existence":0.975,"class_agreement":0.963,"completeness":0.969,"schema_validity":0.97},"scalar":0.963},"decision":"approve","envelope_id":"e5839f9d-7ece-56ec-b8b3-97eeb43e89bd","role":"accounts","user_id":"accounts-b"}	3c65d9b941c8887ed21b438e7766abccb51d724afe41a6eeb0e5c19f2f8270e4	fd0d2c621a26b8ab3a86617db802ff5103b6df01172047f5a9feff04547733a5	appr:e5839f9d-7ece-56ec-b8b3-97eeb43e89bd:accounts-b:approve	f	31	2026-09-13 04:15:19.731628+00
2ab27362-81cb-4ad2-8422-c1cf3f362275	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.732801+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "approve", "class_key": "structure_risk", "confidence": {"scalar": 0.929, "components": {"completeness": 0.95, "class_agreement": 0.956, "schema_validity": 0.956, "citation_existence": 0.929}}, "envelope_id": "af92d0e7-3966-517e-869a-f22c45d5a6d8"}	{"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.929,"class_agreement":0.956,"completeness":0.95,"schema_validity":0.956},"scalar":0.929},"decision":"approve","envelope_id":"af92d0e7-3966-517e-869a-f22c45d5a6d8","role":"compliance","user_id":"compliance"}	fd0d2c621a26b8ab3a86617db802ff5103b6df01172047f5a9feff04547733a5	5ca0c8804709916a1ea48af1419b1e37ba2d653703e9644efb77d873767bf142	appr:af92d0e7-3966-517e-869a-f22c45d5a6d8:compliance:approve	f	32	2026-09-13 04:15:19.732671+00
0a2cc610-febd-4084-b785-1f0239c48eb8	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.733736+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "reject", "class_key": "structure_risk", "confidence": {"scalar": 0.731, "components": {"completeness": 0.737, "class_agreement": 0.781, "schema_validity": 0.755, "citation_existence": 0.731}}, "envelope_id": "d255997c-7ee4-5cd2-a06e-2dfff71e1d36"}	{"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.731,"class_agreement":0.781,"completeness":0.737,"schema_validity":0.755},"scalar":0.731},"decision":"reject","envelope_id":"d255997c-7ee4-5cd2-a06e-2dfff71e1d36","role":"compliance","user_id":"compliance"}	5ca0c8804709916a1ea48af1419b1e37ba2d653703e9644efb77d873767bf142	71cb8b864740fe8ff12575735c835751515954484859baaa15736d9582d4f91f	appr:d255997c-7ee4-5cd2-a06e-2dfff71e1d36:compliance:reject	f	33	2026-09-13 04:15:19.733608+00
66431175-aea0-493f-b4a9-dc788a015c37	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.734683+00	{"id": "principal", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "principal", "decision": "approve", "class_key": "certificate_issue", "confidence": {"scalar": 0.858, "components": {"completeness": 0.917, "class_agreement": 0.918, "schema_validity": 0.904, "citation_existence": 0.858}}, "envelope_id": "dfef6a46-4dec-5c8c-bd4d-e7d5518a5229"}	{"class_key":"certificate_issue","confidence":{"components":{"citation_existence":0.858,"class_agreement":0.918,"completeness":0.917,"schema_validity":0.904},"scalar":0.858},"decision":"approve","envelope_id":"dfef6a46-4dec-5c8c-bd4d-e7d5518a5229","role":"principal","user_id":"principal"}	71cb8b864740fe8ff12575735c835751515954484859baaa15736d9582d4f91f	ed67d203deb8637bf01456964fe10703d80b237dee84029b74a42083b111b737	appr:dfef6a46-4dec-5c8c-bd4d-e7d5518a5229:principal:approve	f	34	2026-09-13 04:15:19.734555+00
f684ab96-d8a4-48de-b9fb-75dfcd094b9c	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.735694+00	{"id": "accounts-a", "kind": "human", "name": "accounts"}	Approval	{"role": "accounts", "user_id": "accounts-a", "decision": "approve", "class_key": "claim_admin", "confidence": {"scalar": 0.888, "components": {"completeness": 0.906, "class_agreement": 0.92, "schema_validity": 0.888, "citation_existence": 0.911}}, "envelope_id": "59d34968-f1d8-5b1d-ba9e-c9f767a2e068"}	{"class_key":"claim_admin","confidence":{"components":{"citation_existence":0.911,"class_agreement":0.92,"completeness":0.906,"schema_validity":0.888},"scalar":0.888},"decision":"approve","envelope_id":"59d34968-f1d8-5b1d-ba9e-c9f767a2e068","role":"accounts","user_id":"accounts-a"}	ed67d203deb8637bf01456964fe10703d80b237dee84029b74a42083b111b737	923cf9d84f9f20a2745473359de93f03f525d99ab7ab744bb317d9ad81d0da8f	appr:59d34968-f1d8-5b1d-ba9e-c9f767a2e068:accounts-a:approve	f	35	2026-09-13 04:15:19.735564+00
049b9f1d-6c21-4fa4-820d-1bbc5dc19cfb	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.736728+00	{"id": "compliance", "kind": "human", "name": "compliance"}	Approval	{"role": "compliance", "user_id": "compliance", "decision": "approve", "class_key": "renewal_pack_unchanged", "confidence": {"scalar": 0.898, "components": {"completeness": 0.898, "class_agreement": 0.942, "schema_validity": 0.914, "citation_existence": 0.924}}, "envelope_id": "37ad5833-33eb-50ae-bb59-93e479a2a189"}	{"class_key":"renewal_pack_unchanged","confidence":{"components":{"citation_existence":0.924,"class_agreement":0.942,"completeness":0.898,"schema_validity":0.914},"scalar":0.898},"decision":"approve","envelope_id":"37ad5833-33eb-50ae-bb59-93e479a2a189","role":"compliance","user_id":"compliance"}	923cf9d84f9f20a2745473359de93f03f525d99ab7ab744bb317d9ad81d0da8f	47e2bb178397588d06a966816b6c5b2681720602da639dc0d4ba957e08176579	appr:37ad5833-33eb-50ae-bb59-93e479a2a189:compliance:approve	f	36	2026-09-13 04:15:19.736598+00
c89d82de-1bf7-43a4-a2e4-a54c22275678	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.7378+00	{"id": "seed", "kind": "system", "name": "seed"}	SeedMarker	{"kind": "historical_decisions", "count": 30}	{"count":30,"kind":"historical_decisions"}	47e2bb178397588d06a966816b6c5b2681720602da639dc0d4ba957e08176579	9eebc09da5ebafdfaf86f1177f0ed335c44b772c0b256c1236e637df3c2ac62b	seed:historical_decisions:v1	f	37	2026-09-13 04:15:19.737674+00
2bb3d1b2-d888-4d48-a077-b44e93f1a176	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.7391+00	{"id": "agent", "kind": "system", "name": "agent"}	AgentOutputProduced	{"output": {"fields": {"mocked_capabilities": ["carrier"]}, "summary": "Proposed action for certificate_issue — awaiting operator review."}, "citations": [], "class_key": "certificate_issue", "confidence": {"scalar": 0.791, "components": {"completeness": 0.811, "class_agreement": 0.791, "schema_validity": 0.802, "citation_existence": 0.833}}, "envelope_id": "7f23ec7b-0606-5169-9599-4082b6484593", "tokens_used": {"input": 0, "output": 0}, "mocked_capabilities": ["carrier"]}	{"citations":[],"class_key":"certificate_issue","confidence":{"components":{"citation_existence":0.833,"class_agreement":0.791,"completeness":0.811,"schema_validity":0.802},"scalar":0.791},"envelope_id":"7f23ec7b-0606-5169-9599-4082b6484593","mocked_capabilities":["carrier"],"output":{"fields":{"mocked_capabilities":["carrier"]},"summary":"Proposed action for certificate_issue — awaiting operator review."},"tokens_used":{"input":0,"output":0}}	9eebc09da5ebafdfaf86f1177f0ed335c44b772c0b256c1236e637df3c2ac62b	3d9e38cdd50f6e750debf253ff015de6ef2ce42e05b54f3318628820ab04bbb9	proposal:7f23ec7b-0606-5169-9599-4082b6484593	t	38	2026-09-13 04:15:19.738957+00
9eddc749-14fc-4bf7-adfc-73e86d4deeb1	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.742275+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "certificate_issue", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.791, "hitl_since": "2026-09-12T23:15:19.738911+00:00", "envelope_id": "7f23ec7b-0606-5169-9599-4082b6484593", "gate_reason": "non_standard_wording", "proposal_ref": "2bb3d1b2-d888-4d48-a077-b44e93f1a176", "sla_deadline": "2026-09-13T03:15:19.738911+00:00", "routed_to_role": "principal"}	{"class_key":"certificate_issue","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.791,"envelope_id":"7f23ec7b-0606-5169-9599-4082b6484593","gate_reason":"non_standard_wording","hitl_since":"2026-09-12T23:15:19.738911+00:00","matter_id":null,"proposal_ref":"2bb3d1b2-d888-4d48-a077-b44e93f1a176","routed_to_role":"principal","sla_deadline":"2026-09-13T03:15:19.738911+00:00"}	3d9e38cdd50f6e750debf253ff015de6ef2ce42e05b54f3318628820ab04bbb9	283922730d714108be896082791790d539c7d6a941c88c5fdf7b3693f621a50a	queue:enqueue:7f23ec7b-0606-5169-9599-4082b6484593	f	39	2026-09-13 04:15:19.742113+00
5fa6a9a3-9dc3-4e8b-b5f0-d13abc341aec	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:40.75125+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationStarted	{"budget": {"max_wall_ms": 45000, "max_input_tokens": 6000, "max_output_tokens": 2000}, "class_key": "endorsement_execute_instructed_quoted", "agent_name": "placement", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"agent_name":"placement","budget":{"max_input_tokens":6000,"max_output_tokens":2000,"max_wall_ms":45000},"class_key":"endorsement_execute_instructed_quoted","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113"}	628451981b27915b9d9e9cb6386d1bcf2f844c2898b8d33c08e2c77f58bd174e	8815c85123b2c5114b447465220afcc1a3040f99c7cccd0855c0895700b22e91	aginv:start:25516a4e-156f-4e01-a3c7-dd714d970113:placement	f	55	2026-09-13 04:15:40.751087+00
7b513c09-8546-46bd-9128-4c541e8b4008	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.743317+00	{"id": "agent", "kind": "system", "name": "agent"}	AgentOutputProduced	{"output": {"fields": {"mocked_capabilities": ["carrier"]}, "summary": "Proposed action for structure_risk — awaiting operator review."}, "citations": [], "class_key": "structure_risk", "confidence": {"scalar": 0.714, "components": {"completeness": 0.714, "class_agreement": 0.755, "schema_validity": 0.728, "citation_existence": 0.772}}, "envelope_id": "44bc4212-d962-56ce-83d8-1c4ca5342913", "tokens_used": {"input": 0, "output": 0}, "mocked_capabilities": ["carrier"]}	{"citations":[],"class_key":"structure_risk","confidence":{"components":{"citation_existence":0.772,"class_agreement":0.755,"completeness":0.714,"schema_validity":0.728},"scalar":0.714},"envelope_id":"44bc4212-d962-56ce-83d8-1c4ca5342913","mocked_capabilities":["carrier"],"output":{"fields":{"mocked_capabilities":["carrier"]},"summary":"Proposed action for structure_risk — awaiting operator review."},"tokens_used":{"input":0,"output":0}}	283922730d714108be896082791790d539c7d6a941c88c5fdf7b3693f621a50a	b8e88debd674a78255eab63be9298727011bda2b9608a0af1520e230e6a9e5a7	proposal:44bc4212-d962-56ce-83d8-1c4ca5342913	t	40	2026-09-13 04:15:19.743165+00
c9e95e0a-879b-4511-8af2-111b2b32e0ed	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.745539+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "structure_risk", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.714, "hitl_since": "2026-09-12T23:15:19.738911+00:00", "envelope_id": "44bc4212-d962-56ce-83d8-1c4ca5342913", "gate_reason": "hitl_predicate matched", "proposal_ref": "7b513c09-8546-46bd-9128-4c541e8b4008", "sla_deadline": "2026-09-13T03:15:19.738911+00:00", "routed_to_role": "principal"}	{"class_key":"structure_risk","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.714,"envelope_id":"44bc4212-d962-56ce-83d8-1c4ca5342913","gate_reason":"hitl_predicate matched","hitl_since":"2026-09-12T23:15:19.738911+00:00","matter_id":null,"proposal_ref":"7b513c09-8546-46bd-9128-4c541e8b4008","routed_to_role":"principal","sla_deadline":"2026-09-13T03:15:19.738911+00:00"}	b8e88debd674a78255eab63be9298727011bda2b9608a0af1520e230e6a9e5a7	6f32663eece688b80c0fd97dfbbd296f6538372589c8d171f0c32b127defefa1	queue:enqueue:44bc4212-d962-56ce-83d8-1c4ca5342913	f	41	2026-09-13 04:15:19.745392+00
e588b50d-fbea-428f-a293-c977d680ccf0	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.746534+00	{"id": "agent", "kind": "system", "name": "agent"}	AgentOutputProduced	{"output": {"fields": {"mocked_capabilities": ["carrier"]}, "summary": "Proposed action for claim_admin — awaiting operator review."}, "citations": [], "class_key": "claim_admin", "confidence": {"scalar": 0.794, "components": {"completeness": 0.859, "class_agreement": 0.806, "schema_validity": 0.818, "citation_existence": 0.794}}, "envelope_id": "9489ea6c-f581-502f-8683-226dd95fd673", "tokens_used": {"input": 0, "output": 0}, "mocked_capabilities": ["carrier"]}	{"citations":[],"class_key":"claim_admin","confidence":{"components":{"citation_existence":0.794,"class_agreement":0.806,"completeness":0.859,"schema_validity":0.818},"scalar":0.794},"envelope_id":"9489ea6c-f581-502f-8683-226dd95fd673","mocked_capabilities":["carrier"],"output":{"fields":{"mocked_capabilities":["carrier"]},"summary":"Proposed action for claim_admin — awaiting operator review."},"tokens_used":{"input":0,"output":0}}	6f32663eece688b80c0fd97dfbbd296f6538372589c8d171f0c32b127defefa1	566b7c5fac7c0ab0cb0eba580218a7bc631bb984d3539b8b297dd52d52ca5d20	proposal:9489ea6c-f581-502f-8683-226dd95fd673	t	42	2026-09-13 04:15:19.746391+00
aa28087d-1ced-41ed-aba0-c38343364fee	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.748532+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "claim_admin", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.794, "hitl_since": "2026-09-12T21:15:19.738911+00:00", "envelope_id": "9489ea6c-f581-502f-8683-226dd95fd673", "gate_reason": "coverage_language_detected", "proposal_ref": "e588b50d-fbea-428f-a293-c977d680ccf0", "sla_deadline": "2026-09-13T05:15:19.738911+00:00", "routed_to_role": "principal"}	{"class_key":"claim_admin","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.794,"envelope_id":"9489ea6c-f581-502f-8683-226dd95fd673","gate_reason":"coverage_language_detected","hitl_since":"2026-09-12T21:15:19.738911+00:00","matter_id":null,"proposal_ref":"e588b50d-fbea-428f-a293-c977d680ccf0","routed_to_role":"principal","sla_deadline":"2026-09-13T05:15:19.738911+00:00"}	566b7c5fac7c0ab0cb0eba580218a7bc631bb984d3539b8b297dd52d52ca5d20	9cb0a71efddbf84f9ea2b9e0b72755aa7e34d6d0581570bc149a12f7fac50351	queue:enqueue:9489ea6c-f581-502f-8683-226dd95fd673	f	43	2026-09-13 04:15:19.748382+00
700508fa-c83c-42b9-88a4-c6b6bdb48018	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.749649+00	{"id": "agent", "kind": "system", "name": "agent"}	AgentOutputProduced	{"output": {"fields": {"mocked_capabilities": ["carrier"]}, "summary": "Proposed action for endorsement_execute_instructed_quoted — awaiting operator review."}, "citations": [], "class_key": "endorsement_execute_instructed_quoted", "confidence": {"scalar": 0.762, "components": {"completeness": 0.788, "class_agreement": 0.785, "schema_validity": 0.762, "citation_existence": 0.777}}, "envelope_id": "6f410c2c-737a-54e9-af9e-ac4917c33a92", "tokens_used": {"input": 0, "output": 0}, "mocked_capabilities": ["carrier"]}	{"citations":[],"class_key":"endorsement_execute_instructed_quoted","confidence":{"components":{"citation_existence":0.777,"class_agreement":0.785,"completeness":0.788,"schema_validity":0.762},"scalar":0.762},"envelope_id":"6f410c2c-737a-54e9-af9e-ac4917c33a92","mocked_capabilities":["carrier"],"output":{"fields":{"mocked_capabilities":["carrier"]},"summary":"Proposed action for endorsement_execute_instructed_quoted — awaiting operator review."},"tokens_used":{"input":0,"output":0}}	9cb0a71efddbf84f9ea2b9e0b72755aa7e34d6d0581570bc149a12f7fac50351	5109defc8d0fedc6e83595121ab9d85b30d69eef4fd5c471304b7f6b7fbee494	proposal:6f410c2c-737a-54e9-af9e-ac4917c33a92	t	44	2026-09-13 04:15:19.749504+00
ed2f84df-c62d-4f9a-b56b-bf30c5312990	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.75177+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "endorsement_execute_instructed_quoted", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.762, "hitl_since": "2026-09-12T05:15:19.738911+00:00", "envelope_id": "6f410c2c-737a-54e9-af9e-ac4917c33a92", "gate_reason": "ambiguous_reply", "proposal_ref": "700508fa-c83c-42b9-88a4-c6b6bdb48018", "sla_deadline": "2026-09-13T05:15:19.738911+00:00", "routed_to_role": "principal"}	{"class_key":"endorsement_execute_instructed_quoted","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.762,"envelope_id":"6f410c2c-737a-54e9-af9e-ac4917c33a92","gate_reason":"ambiguous_reply","hitl_since":"2026-09-12T05:15:19.738911+00:00","matter_id":null,"proposal_ref":"700508fa-c83c-42b9-88a4-c6b6bdb48018","routed_to_role":"principal","sla_deadline":"2026-09-13T05:15:19.738911+00:00"}	5109defc8d0fedc6e83595121ab9d85b30d69eef4fd5c471304b7f6b7fbee494	8cb511ecec2f45f7e25ac079ce28ede0e18b289312257f765b9ae00d4ac99d05	queue:enqueue:6f410c2c-737a-54e9-af9e-ac4917c33a92	f	45	2026-09-13 04:15:19.75162+00
0128ad01-42ec-4966-a18f-cbdade366882	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.752879+00	{"id": "agent", "kind": "system", "name": "agent"}	AgentOutputProduced	{"output": {"fields": {"mocked_capabilities": ["carrier"]}, "summary": "Proposed action for submit_to_market — awaiting operator review."}, "citations": [], "class_key": "submit_to_market", "confidence": {"scalar": 0.692, "components": {"completeness": 0.739, "class_agreement": 0.707, "schema_validity": 0.711, "citation_existence": 0.692}}, "envelope_id": "ffd21553-fd55-5cee-9075-5be95befa632", "tokens_used": {"input": 0, "output": 0}, "mocked_capabilities": ["carrier"]}	{"citations":[],"class_key":"submit_to_market","confidence":{"components":{"citation_existence":0.692,"class_agreement":0.707,"completeness":0.739,"schema_validity":0.711},"scalar":0.692},"envelope_id":"ffd21553-fd55-5cee-9075-5be95befa632","mocked_capabilities":["carrier"],"output":{"fields":{"mocked_capabilities":["carrier"]},"summary":"Proposed action for submit_to_market — awaiting operator review."},"tokens_used":{"input":0,"output":0}}	8cb511ecec2f45f7e25ac079ce28ede0e18b289312257f765b9ae00d4ac99d05	7a75bf2a8b2dd960d349a05f6c57518c9951f342b08593b443eeb8a23681eaa0	proposal:ffd21553-fd55-5cee-9075-5be95befa632	t	46	2026-09-13 04:15:19.752738+00
dcfc15db-541a-4de3-9189-411477f66c14	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.755027+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "submit_to_market", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.692, "hitl_since": "2026-09-13T04:14:19.738911+00:00", "envelope_id": "ffd21553-fd55-5cee-9075-5be95befa632", "gate_reason": "new_business", "proposal_ref": "0128ad01-42ec-4966-a18f-cbdade366882", "sla_deadline": "2026-09-14T04:14:19.738911+00:00", "routed_to_role": "accounts"}	{"class_key":"submit_to_market","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.692,"envelope_id":"ffd21553-fd55-5cee-9075-5be95befa632","gate_reason":"new_business","hitl_since":"2026-09-13T04:14:19.738911+00:00","matter_id":null,"proposal_ref":"0128ad01-42ec-4966-a18f-cbdade366882","routed_to_role":"accounts","sla_deadline":"2026-09-14T04:14:19.738911+00:00"}	7a75bf2a8b2dd960d349a05f6c57518c9951f342b08593b443eeb8a23681eaa0	72aff0219d0215eacfd514a7b7eba5317dfac27406c065ad422c2ee27fc2a672	queue:enqueue:ffd21553-fd55-5cee-9075-5be95befa632	f	47	2026-09-13 04:15:19.754892+00
feb15a59-cf39-4a44-b97f-c3af3e3cd973	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.75604+00	{"id": "seed", "kind": "system", "name": "seed"}	SeedMarker	{"kind": "queue_cards", "count": 5}	{"count":5,"kind":"queue_cards"}	72aff0219d0215eacfd514a7b7eba5317dfac27406c065ad422c2ee27fc2a672	40bb4905b274bcdc87b74c44b0e8810d07bf69f4c743bc6078df1e2a8615be38	seed:queue_cards:v1	f	48	2026-09-13 04:15:19.755901+00
ade247da-3f93-478f-b1c1-c77db23900cd	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.758293+00	{"id": "seed", "kind": "system", "name": "phase11-seed"}	ClientEntityCreated	{"domicile": "Melbourne, AU", "industry": "shipping", "client_id": "00000000-0000-4000-8000-000000000003", "fictional": true, "display_name": "Kelp Shipping Co. Pty Ltd", "vulnerable_flag": true, "jurisdiction_code": "AU"}	{"client_id":"00000000-0000-4000-8000-000000000003","display_name":"Kelp Shipping Co. Pty Ltd","domicile":"Melbourne, AU","fictional":true,"industry":"shipping","jurisdiction_code":"AU","vulnerable_flag":true}	40bb4905b274bcdc87b74c44b0e8810d07bf69f4c743bc6078df1e2a8615be38	ac22798213d07288ad46d7b0687b096402d7427dafb02118236545c4ea858abd	seed:client:00000000-0000-4000-8000-000000000003	f	49	2026-09-13 04:15:19.758132+00
97f6f3cc-be68-44ad-ba3c-42f018baa469	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:19.759363+00	{"id": "seed", "kind": "system", "name": "phase11-seed"}	PolicyCreated	{"status": "managed", "product": "Marine Cargo", "client_id": "00000000-0000-4000-8000-000000000003", "fictional": true, "policy_id": "00000000-0000-4000-8000-000000000103", "premium_amount": 4200.0, "insurer_display": "Fictional Carrier B", "premium_currency": "AUD"}	{"client_id":"00000000-0000-4000-8000-000000000003","fictional":true,"insurer_display":"Fictional Carrier B","policy_id":"00000000-0000-4000-8000-000000000103","premium_amount":4200,"premium_currency":"AUD","product":"Marine Cargo","status":"managed"}	ac22798213d07288ad46d7b0687b096402d7427dafb02118236545c4ea858abd	94d24a0de94e8f12fe09142f17e3ac492195f16dc81ca91c21dba115ca26d6ad	seed:policy:00000000-0000-4000-8000-000000000103	f	50	2026-09-13 04:15:19.759231+00
75103282-5f44-4394-ae7d-f14925712dd1	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:35.938202+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	ClientChangeRequested	{"client_id": "00000000-0000-4000-8000-000000000001", "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "raw_message": "We took on a bigger contract. Please raise our public liability from $10M to $20M."}	{"client_id":"00000000-0000-4000-8000-000000000001","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","policy_id":"00000000-0000-4000-8000-000000000101","raw_message":"We took on a bigger contract. Please raise our public liability from $10M to $20M."}	94d24a0de94e8f12fe09142f17e3ac492195f16dc81ca91c21dba115ca26d6ad	756726d61b889f97d19434ca159dc169672fe9d3795e9db8397200d9ee224ac9	cchreq:25516a4e-156f-4e01-a3c7-dd714d970113	f	51	2026-09-13 04:15:35.938043+00
6edfd8e1-e0a7-4dd4-bab0-0cae3ed68f03	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:35.940611+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationStarted	{"budget": {"max_wall_ms": 45000, "max_input_tokens": 4000, "max_output_tokens": 1500}, "class_key": "request_info", "agent_name": "intake", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"agent_name":"intake","budget":{"max_input_tokens":4000,"max_output_tokens":1500,"max_wall_ms":45000},"class_key":"request_info","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113"}	756726d61b889f97d19434ca159dc169672fe9d3795e9db8397200d9ee224ac9	8e0d49d9d53dc1b5107d46ae3b91dba9922600196aadf0f12251006aa947ec6a	aginv:start:25516a4e-156f-4e01-a3c7-dd714d970113:intake	f	52	2026-09-13 04:15:35.940407+00
84dd813d-a62a-4a08-9b99-8e5284ce93ae	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:15:40.747747+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentOutputProduced	{"flags": {"input_tokens_overrun": false}, "wall_ms": 4804, "decision": "propose", "citations": [{"ref": "schedule.limits.public_liability", "kind": "risk_schema"}], "class_key": "endorsement_execute_instructed_quoted", "agent_name": "intake", "confidence": {"scalar": 0.0, "components": {"completeness": 1.0, "class_agreement": 0.0, "schema_validity": 0.0, "citation_existence": 1.0}}, "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "tokens_used": {"input": 2289, "output": 341}}	{"agent_name":"intake","citations":[{"kind":"risk_schema","ref":"schedule.limits.public_liability"}],"class_key":"endorsement_execute_instructed_quoted","confidence":{"components":{"citation_existence":1,"class_agreement":0,"completeness":1,"schema_validity":0},"scalar":0},"decision":"propose","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","flags":{"input_tokens_overrun":false},"tokens_used":{"input":2289,"output":341},"wall_ms":4804}	8e0d49d9d53dc1b5107d46ae3b91dba9922600196aadf0f12251006aa947ec6a	a82fb9503161507bd978c0351d5454b9c3e831bba42570505964bf3c9ffa6784	aginv:output:25516a4e-156f-4e01-a3c7-dd714d970113:intake	f	53	2026-09-13 04:15:40.746684+00
7b7a5ad2-3af8-4fe1-9c93-9dcfcd727117	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:03.988395+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentOutputProduced	{"flags": {"input_tokens_overrun": false}, "wall_ms": 23234, "decision": "propose", "citations": [{"ref": "cover_type:public_liability", "kind": "risk_schema"}, {"ref": "intake-upstream-ref", "kind": "event"}], "class_key": "endorsement_execute_instructed_quoted", "agent_name": "placement", "confidence": {"scalar": 1.0, "components": {"completeness": 1.0, "class_agreement": 1.0, "schema_validity": 1.0, "citation_existence": 1.0}}, "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "tokens_used": {"input": 2594, "output": 1500}}	{"agent_name":"placement","citations":[{"kind":"risk_schema","ref":"cover_type:public_liability"},{"kind":"event","ref":"intake-upstream-ref"}],"class_key":"endorsement_execute_instructed_quoted","confidence":{"components":{"citation_existence":1,"class_agreement":1,"completeness":1,"schema_validity":1},"scalar":1},"decision":"propose","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","flags":{"input_tokens_overrun":false},"tokens_used":{"input":2594,"output":1500},"wall_ms":23234}	8815c85123b2c5114b447465220afcc1a3040f99c7cccd0855c0895700b22e91	8fe17fd63fb06d6696f74bda4e75e1498ab7d4cc0fe1f8f6f45bd0a4ef4f332d	aginv:output:25516a4e-156f-4e01-a3c7-dd714d970113:placement	f	56	2026-09-13 04:16:03.987342+00
2ec5c319-d6c8-4360-8e65-2cf973b255ec	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:03.990768+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationCompleted	{"outcome": "ok", "agent_name": "placement", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"agent_name":"placement","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","outcome":"ok"}	8fe17fd63fb06d6696f74bda4e75e1498ab7d4cc0fe1f8f6f45bd0a4ef4f332d	36f5e325455cc51b46a7a912f65cc98c7a88e1433fde154ba2515d148ba287b3	aginv:done:25516a4e-156f-4e01-a3c7-dd714d970113:placement	f	57	2026-09-13 04:16:03.990613+00
34f733d3-5134-4436-8c71-388ea8d4a305	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:03.991784+00	{"id": "placement", "kind": "system", "name": "placement"}	SubmissionDrafted	{"mocked": false, "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "submission_summary": "Client requests an uplift to the public liability any-one-occurrence limit under an existing Marine Liability policy, driven by a new, larger contract. The policy is currently in force and managed with the incumbent carrier.", "structured_submission": {"cover_type": "public_liability", "market_targets": ["Fictional Carrier A", "Fictional Carrier B", "Fictional Carrier C"], "risk_description": "The insured holds a Marine Liability policy (policy ID 00000000-0000-4000-8000-000000000101) with Public Liability and Products Liability covers in place. Territorial limits are Worldwide excluding USA/Canada, with a per-occurrence excess of AUD 25,000. The client seeks to increase the Public Liability any-one-occurrence limit, citing a new contract requiring higher limits. The aggregate limit and Products Liability sublimits are not proposed to change at this stage.", "requested_changes": [{"citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.limits.public_liability"}, "to_value": 20000000, "operation": "increase", "field_path": "schedule.limits.public_liability", "from_value": 10000000}], "underwriter_questions_answered": [{"answer": "AUD 10,000,000 any one occurrence, as per the current policy schedule.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.cover_types[0].limit_any_one"}, "question": "What is the current Public Liability any-one-occurrence limit?"}, {"answer": "AUD 20,000,000 any one occurrence, as requested by the client.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.limits.public_liability"}, "question": "What is the requested Public Liability any-one-occurrence limit?"}, {"answer": "AUD 20,000,000 in the aggregate, as per the current policy schedule. No change to the aggregate is proposed.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.cover_types[0].aggregate"}, "question": "What is the current Public Liability aggregate limit?"}, {"answer": "Worldwide excluding USA/Canada, as per the current policy schedule.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.territorial_limits"}, "question": "What is the territorial scope of the cover?"}, {"answer": "AUD 25,000 any one occurrence, as per the current policy schedule.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.excess.any_one_occurrence"}, "question": "What is the policy excess?"}, {"answer": "The client has cited a larger contract requiring higher public liability limits.", "citation": {"kind": "event", "event_id": "intake-upstream-ref", "field_path": "parsed_intent"}, "question": "What is the reason for the requested limit increase?"}, {"answer": "No. The proposed change is limited to the Public Liability any-one-occurrence limit only. Products Liability limits remain at AUD 10,000,000 any one occurrence and AUD 20,000,000 in the aggregate.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.cover_types[1]"}, "question": "Are Products Liability limits proposed to change?"}]}, "recommended_wording_ref": "standard_marine_pl_v3"}	{"envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mocked":false,"policy_id":"00000000-0000-4000-8000-000000000101","recommended_wording_ref":"standard_marine_pl_v3","structured_submission":{"cover_type":"public_liability","market_targets":["Fictional Carrier A","Fictional Carrier B","Fictional Carrier C"],"requested_changes":[{"citation":{"field_path":"schedule.limits.public_liability","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"field_path":"schedule.limits.public_liability","from_value":10000000,"operation":"increase","to_value":20000000}],"risk_description":"The insured holds a Marine Liability policy (policy ID 00000000-0000-4000-8000-000000000101) with Public Liability and Products Liability covers in place. Territorial limits are Worldwide excluding USA/Canada, with a per-occurrence excess of AUD 25,000. The client seeks to increase the Public Liability any-one-occurrence limit, citing a new contract requiring higher limits. The aggregate limit and Products Liability sublimits are not proposed to change at this stage.","underwriter_questions_answered":[{"answer":"AUD 10,000,000 any one occurrence, as per the current policy schedule.","citation":{"field_path":"schedule.cover_types[0].limit_any_one","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the current Public Liability any-one-occurrence limit?"},{"answer":"AUD 20,000,000 any one occurrence, as requested by the client.","citation":{"field_path":"schedule.limits.public_liability","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the requested Public Liability any-one-occurrence limit?"},{"answer":"AUD 20,000,000 in the aggregate, as per the current policy schedule. No change to the aggregate is proposed.","citation":{"field_path":"schedule.cover_types[0].aggregate","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the current Public Liability aggregate limit?"},{"answer":"Worldwide excluding USA/Canada, as per the current policy schedule.","citation":{"field_path":"schedule.territorial_limits","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the territorial scope of the cover?"},{"answer":"AUD 25,000 any one occurrence, as per the current policy schedule.","citation":{"field_path":"schedule.excess.any_one_occurrence","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the policy excess?"},{"answer":"The client has cited a larger contract requiring higher public liability limits.","citation":{"event_id":"intake-upstream-ref","field_path":"parsed_intent","kind":"event"},"question":"What is the reason for the requested limit increase?"},{"answer":"No. The proposed change is limited to the Public Liability any-one-occurrence limit only. Products Liability limits remain at AUD 10,000,000 any one occurrence and AUD 20,000,000 in the aggregate.","citation":{"field_path":"schedule.cover_types[1]","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"Are Products Liability limits proposed to change?"}]},"submission_summary":"Client requests an uplift to the public liability any-one-occurrence limit under an existing Marine Liability policy, driven by a new, larger contract. The policy is currently in force and managed with the incumbent carrier."}	36f5e325455cc51b46a7a912f65cc98c7a88e1433fde154ba2515d148ba287b3	017aa04428614d5b586aed9b1699bbe43422055e4f942d4a006eae6ed4c16f49	placement:submission:25516a4e-156f-4e01-a3c7-dd714d970113	f	58	2026-09-13 04:16:03.991647+00
40aa545b-840f-492d-b973-25cb474676cf	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:03.993453+00	{"id": "carrier_channel", "kind": "system", "name": "carrier"}	CarrierQuoted	{"terms": "Quote valid for 40 days. Subject to executed endorsement wording.", "mocked": true, "quote_id": "ffd66a91-62bc-72af-5c73-ca9e0ad9cd0d", "policy_id": "00000000-0000-4000-8000-000000000101", "quoted_at": "2026-09-13T04:16:03.993262+00:00", "conditions": ["Certificate must be issued within 30 days of bind.", "Continuous cover confirmed — no gap since last renewal."], "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "carrier_name": "Fictional Carrier B", "premium_currency": "AUD", "premium_new_annual": "508500.00", "premium_change_amount": "500000.00"}	{"carrier_name":"Fictional Carrier B","conditions":["Certificate must be issued within 30 days of bind.","Continuous cover confirmed — no gap since last renewal."],"envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","premium_change_amount":"500000.00","premium_currency":"AUD","premium_new_annual":"508500.00","quote_id":"ffd66a91-62bc-72af-5c73-ca9e0ad9cd0d","quoted_at":"2026-09-13T04:16:03.993262+00:00","terms":"Quote valid for 40 days. Subject to executed endorsement wording."}	017aa04428614d5b586aed9b1699bbe43422055e4f942d4a006eae6ed4c16f49	9893b2f10d7c393a393c4c7a7f1baa6ef8aa9d210760b2b29a365ea2eaa451d4	carrier:quote:25516a4e-156f-4e01-a3c7-dd714d970113	t	59	2026-09-13 04:16:03.993297+00
610be08f-2ae1-466f-9f1b-d53f9ea0a57b	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:03.994646+00	{"id": "orchestrator", "kind": "system", "name": "orchestrator"}	EndorsementQuoteReady	{"quote_id": "ffd66a91-62bc-72af-5c73-ca9e0ad9cd0d", "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","policy_id":"00000000-0000-4000-8000-000000000101","quote_id":"ffd66a91-62bc-72af-5c73-ca9e0ad9cd0d"}	9893b2f10d7c393a393c4c7a7f1baa6ef8aa9d210760b2b29a365ea2eaa451d4	82756e4e46b8b7a3bb15bc89600805b6b441e244a30f5a60b03e3b70087ad0f8	quote:ready:25516a4e-156f-4e01-a3c7-dd714d970113	f	60	2026-09-13 04:16:03.994499+00
06bf1430-fa0b-4cef-ba3f-eb65ee5f759e	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:03.996509+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "endorsement_execute_instructed_quoted", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.9, "hitl_since": "2026-09-13T04:16:03.995429+00:00", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "gate_reason": "quote_ready_operator_confirmation_required", "proposal_ref": "610be08f-2ae1-466f-9f1b-d53f9ea0a57b", "sla_deadline": "2026-09-14T04:16:03.995429+00:00", "routed_to_role": "principal"}	{"class_key":"endorsement_execute_instructed_quoted","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.9,"envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","gate_reason":"quote_ready_operator_confirmation_required","hitl_since":"2026-09-13T04:16:03.995429+00:00","matter_id":null,"proposal_ref":"610be08f-2ae1-466f-9f1b-d53f9ea0a57b","routed_to_role":"principal","sla_deadline":"2026-09-14T04:16:03.995429+00:00"}	82756e4e46b8b7a3bb15bc89600805b6b441e244a30f5a60b03e3b70087ad0f8	ac47cbacb04d6dcace1940682af4855e66ce4cf1b7bac6abf784853e600c2d53	queue:enqueue:25516a4e-156f-4e01-a3c7-dd714d970113	f	61	2026-09-13 04:16:03.996371+00
1d6acb32-2069-48c4-93bf-dadbb03112d3	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:19:53.895646+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationCompleted	{"outcome": "ok", "agent_name": "intake", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"agent_name":"intake","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","outcome":"ok"}	d9705215237828f350596e23ebf5a97254f6c23e74f3997a4ac4dde6e43f16ab	3668d3c5c1512f85327ce5f707bd85e9ed118f27089e37a35cee55a20ee616a0	aginv:done:c546b656-1aa6-45c8-9379-f5dd571f5843:intake	f	84	2026-09-13 04:19:53.895433+00
970bd516-4868-46c2-875c-3d15d5d80048	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:25.664666+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	PaymentMandateCreated	{"amount": "500000.00", "mocked": true, "status": "pending", "currency": "AUD", "client_id": "00000000-0000-4000-8000-000000000001", "policy_id": "00000000-0000-4000-8000-000000000101", "created_at": "2026-09-13T04:16:25.664191+00:00", "mandate_id": "df8bee66-d1e9-9808-0ccd-3c25162a6c49", "rail_label": "PayTo", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"amount":"500000.00","client_id":"00000000-0000-4000-8000-000000000001","created_at":"2026-09-13T04:16:25.664191+00:00","currency":"AUD","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mandate_id":"df8bee66-d1e9-9808-0ccd-3c25162a6c49","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","rail_label":"PayTo","status":"pending"}	ac47cbacb04d6dcace1940682af4855e66ce4cf1b7bac6abf784853e600c2d53	b86e3db5bbe072c7dcf6d2786a9e418aec1a0facae1c7892eab80b2223a3d5a7	payment:mandate:25516a4e-156f-4e01-a3c7-dd714d970113	t	62	2026-09-13 04:16:25.664303+00
741502d3-00a1-48dd-b39b-ec364f11f295	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:25.666157+00	{"id": "payment_rail", "kind": "system", "name": "payment"}	PaymentInitiated	{"amount": "500000.00", "mocked": true, "currency": "AUD", "policy_id": "00000000-0000-4000-8000-000000000101", "mandate_id": "df8bee66-d1e9-9808-0ccd-3c25162a6c49", "rail_label": "PayTo", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"amount":"500000.00","currency":"AUD","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mandate_id":"df8bee66-d1e9-9808-0ccd-3c25162a6c49","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","rail_label":"PayTo"}	b86e3db5bbe072c7dcf6d2786a9e418aec1a0facae1c7892eab80b2223a3d5a7	a7fc68fdc5b617f5575a928c2dde05b4ebef5c39a6f837143fc9a55db0564241	payment:initiated:25516a4e-156f-4e01-a3c7-dd714d970113	t	63	2026-09-13 04:16:25.665998+00
518e58cd-c7a6-4492-861b-e5c0eaa21293	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:25.868057+00	{"id": "payment_rail", "kind": "system", "name": "payment"}	PaymentReceived	{"ref": "MOCK-PAYTO-3e92585a", "amount": "500000.00", "mocked": true, "status": "succeeded", "currency": "AUD", "quote_id": "ffd66a91-62bc-72af-5c73-ca9e0ad9cd0d", "policy_id": "00000000-0000-4000-8000-000000000101", "mandate_id": "df8bee66-d1e9-9808-0ccd-3c25162a6c49", "payment_id": "767b5658-a8c5-2c0c-e214-18dbc6bb9c59", "rail_label": "PayTo", "settled_at": "2026-09-13T04:16:25.867581+00:00", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"amount":"500000.00","currency":"AUD","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mandate_id":"df8bee66-d1e9-9808-0ccd-3c25162a6c49","mocked":true,"payment_id":"767b5658-a8c5-2c0c-e214-18dbc6bb9c59","policy_id":"00000000-0000-4000-8000-000000000101","quote_id":"ffd66a91-62bc-72af-5c73-ca9e0ad9cd0d","rail_label":"PayTo","ref":"MOCK-PAYTO-3e92585a","settled_at":"2026-09-13T04:16:25.867581+00:00","status":"succeeded"}	a7fc68fdc5b617f5575a928c2dde05b4ebef5c39a6f837143fc9a55db0564241	8bff98f652dabfd3ca3cd4e6c237c38d3d3c554f3cb620fadbdac0162e4e792b	payment:received:25516a4e-156f-4e01-a3c7-dd714d970113	t	64	2026-09-13 04:16:25.867716+00
5d1bce21-7a31-4798-a1f4-16ba73bbffce	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:27.937242+00	{"id": "e_sign", "kind": "system", "name": "e_sign"}	SignatureRequested	{"mocked": true, "status": "sent", "policy_id": "00000000-0000-4000-8000-000000000101", "created_at": "2026-09-13T04:16:27.936831+00:00", "request_id": "9c50b4c1-db39-e664-96dd-5ae434ae3dcb", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "document_ref": "endorsement:25516a4e-156f-4e01-a3c7-dd714d970113", "signer_email": "debc6759-260c-4214-a0d6-1ce287dd3137@example.test"}	{"created_at":"2026-09-13T04:16:27.936831+00:00","document_ref":"endorsement:25516a4e-156f-4e01-a3c7-dd714d970113","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","request_id":"9c50b4c1-db39-e664-96dd-5ae434ae3dcb","signer_email":"debc6759-260c-4214-a0d6-1ce287dd3137@example.test","status":"sent"}	8bff98f652dabfd3ca3cd4e6c237c38d3d3c554f3cb620fadbdac0162e4e792b	9064665b47b48101f444de5970880c1783d954c4dbabdcc4ad9d086c47c1f60b	esign:req:25516a4e-156f-4e01-a3c7-dd714d970113	t	65	2026-09-13 04:16:27.936936+00
ac4e757f-0396-4490-a24c-dc11d030d744	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:28.089336+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	SignatureCompleted	{"mocked": true, "status": "signed", "policy_id": "00000000-0000-4000-8000-000000000101", "signed_at": "2026-09-13T04:16:28.088903+00:00", "request_id": "9c50b4c1-db39-e664-96dd-5ae434ae3dcb", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "signature_id": "a1260a29-05a4-cb22-9b57-c63ec908f13c", "signature_blob_hash": "b217d1850fcee0e5784513fdfde9658c31971b35b407aa3c51dcad7a4a15c1e5"}	{"envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","request_id":"9c50b4c1-db39-e664-96dd-5ae434ae3dcb","signature_blob_hash":"b217d1850fcee0e5784513fdfde9658c31971b35b407aa3c51dcad7a4a15c1e5","signature_id":"a1260a29-05a4-cb22-9b57-c63ec908f13c","signed_at":"2026-09-13T04:16:28.088903+00:00","status":"signed"}	9064665b47b48101f444de5970880c1783d954c4dbabdcc4ad9d086c47c1f60b	634c98ca8f690da3b55ba438c8d17bc9b8f0e7b1a2375336b3d7c7e2445bb67b	esign:sig:25516a4e-156f-4e01-a3c7-dd714d970113	t	66	2026-09-13 04:16:28.08902+00
424ceb11-4c16-4f54-a721-92aed0969144	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:56.872543+00	{"id": "3eca1652-801e-44e5-84c2-7b6823a7d8dc", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "3eca1652-801e-44e5-84c2-7b6823a7d8dc", "decision": "approve", "class_key": "endorsement_execute_instructed_quoted", "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}	{"class_key":"endorsement_execute_instructed_quoted","decision":"approve","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","policy_id":"00000000-0000-4000-8000-000000000101","role":"principal","user_id":"3eca1652-801e-44e5-84c2-7b6823a7d8dc"}	634c98ca8f690da3b55ba438c8d17bc9b8f0e7b1a2375336b3d7c7e2445bb67b	168b7a51f52a6d1407d53bd57b97c4036261146002e987fa8e770c089891ca18	appr:25516a4e-156f-4e01-a3c7-dd714d970113:3eca1652-801e-44e5-84c2-7b6823a7d8dc:approve	f	67	2026-09-13 04:16:56.871807+00
afbe87cb-e4bc-417c-aa3b-c3181669ca31	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:56.875072+00	{"id": "sms", "kind": "system", "name": "sms"}	SmsSuppressedForOperatorReview	{"mocked": true, "reason": "vulnerable_flag", "message": "Confirming your endorsement has been placed.", "client_id": "00000000-0000-4000-8000-000000000003", "matter_id": null, "envelope_id": "3abf9d00-8bd8-47a5-8a57-d6ca7edebc47", "would_have_sent": true}	{"client_id":"00000000-0000-4000-8000-000000000003","envelope_id":"3abf9d00-8bd8-47a5-8a57-d6ca7edebc47","matter_id":null,"message":"Confirming your endorsement has been placed.","mocked":true,"reason":"vulnerable_flag","would_have_sent":true}	168b7a51f52a6d1407d53bd57b97c4036261146002e987fa8e770c089891ca18	ea926d540b20df1afd8a9ba66d17051f09da8718de3a87c9d130e1a86cf9a3ba	sms:suppressed:3abf9d00-8bd8-47a5-8a57-d6ca7edebc47	t	68	2026-09-13 04:16:56.874892+00
609f75d3-4123-42ab-a755-d92c3b14f380	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:19:53.896884+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationStarted	{"budget": {"max_wall_ms": 45000, "max_input_tokens": 6000, "max_output_tokens": 2000}, "class_key": "endorsement_execute_instructed_quoted", "agent_name": "placement", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"agent_name":"placement","budget":{"max_input_tokens":6000,"max_output_tokens":2000,"max_wall_ms":45000},"class_key":"endorsement_execute_instructed_quoted","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843"}	3668d3c5c1512f85327ce5f707bd85e9ed118f27089e37a35cee55a20ee616a0	a0188de5005c0050f7a40dffcc9a842c7a4eb2ce14b5cc6dab684e0fbb742b2b	aginv:start:c546b656-1aa6-45c8-9379-f5dd571f5843:placement	f	85	2026-09-13 04:19:53.896695+00
410270dc-3c4d-447f-aed2-9d4725d2da9a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:16:56.877453+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "comms_service", "client_id": "00000000-0000-4000-8000-000000000003", "matter_id": null, "confidence": null, "hitl_since": "2026-09-13T04:16:56.875974+00:00", "envelope_id": "3abf9d00-8bd8-47a5-8a57-d6ca7edebc47", "gate_reason": "vulnerable_flag_set", "proposal_ref": "afbe87cb-e4bc-417c-aa3b-c3181669ca31", "sla_deadline": "2026-09-14T04:16:56.875974+00:00", "routed_to_role": "account_executive"}	{"class_key":"comms_service","client_id":"00000000-0000-4000-8000-000000000003","confidence":null,"envelope_id":"3abf9d00-8bd8-47a5-8a57-d6ca7edebc47","gate_reason":"vulnerable_flag_set","hitl_since":"2026-09-13T04:16:56.875974+00:00","matter_id":null,"proposal_ref":"afbe87cb-e4bc-417c-aa3b-c3181669ca31","routed_to_role":"account_executive","sla_deadline":"2026-09-14T04:16:56.875974+00:00"}	ea926d540b20df1afd8a9ba66d17051f09da8718de3a87c9d130e1a86cf9a3ba	87d59ef5b2e97bed8eb04068c62a04827b63a98606a4d4ff13719e4573b5f407	queue:enqueue:3abf9d00-8bd8-47a5-8a57-d6ca7edebc47	f	69	2026-09-13 04:16:56.87725+00
fceb11cd-3455-4f57-97ad-0fd6e192b3d1	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:17:39.333989+00	{"id": "endorsement", "kind": "system", "name": "endorsement"}	EndorsementExecuted	{"policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "effective_date": "2026-09-13T04:17:39.332246+00:00", "endorsement_id": "d61ba3e6-3a84-4f87-8ad8-e3903bc42637", "changes_applied": [{"citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.limits.public_liability"}, "to_value": 20000000, "operation": "increase", "field_path": "schedule.limits.public_liability", "from_value": 10000000}], "mocked_channels": ["carrier", "payment", "e_sign"]}	{"changes_applied":[{"citation":{"field_path":"schedule.limits.public_liability","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"field_path":"schedule.limits.public_liability","from_value":10000000,"operation":"increase","to_value":20000000}],"effective_date":"2026-09-13T04:17:39.332246+00:00","endorsement_id":"d61ba3e6-3a84-4f87-8ad8-e3903bc42637","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mocked_channels":["carrier","payment","e_sign"],"policy_id":"00000000-0000-4000-8000-000000000101"}	87d59ef5b2e97bed8eb04068c62a04827b63a98606a4d4ff13719e4573b5f407	c5b735f2c304405245568cc45779fba192b2f2b4c86d1747dbceb6f35cf34eeb	endorsement:exec:25516a4e-156f-4e01-a3c7-dd714d970113	f	70	2026-09-13 04:17:39.333828+00
4b8d05c3-085a-43c4-9c8f-6708974ab723	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:17:39.335167+00	{"id": "endorsement", "kind": "system", "name": "endorsement"}	PolicyUpdated	{"policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "endorsement_id": "d61ba3e6-3a84-4f87-8ad8-e3903bc42637", "schedule_after": {"excess": {"currency": "AUD", "any_one_occurrence": 25000}, "limits": {"public_liability": 20000000}, "cover_types": [{"type": "Public Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}, {"type": "Products Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}], "territorial_limits": "Worldwide excl. USA/Canada"}}	{"endorsement_id":"d61ba3e6-3a84-4f87-8ad8-e3903bc42637","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","policy_id":"00000000-0000-4000-8000-000000000101","schedule_after":{"cover_types":[{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Public Liability"},{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Products Liability"}],"excess":{"any_one_occurrence":25000,"currency":"AUD"},"limits":{"public_liability":20000000},"territorial_limits":"Worldwide excl. USA/Canada"}}	c5b735f2c304405245568cc45779fba192b2f2b4c86d1747dbceb6f35cf34eeb	4c3308993fd54ff298424914bc108e8737639a15f93648f472ac2dbc3f21865e	policy:updated:25516a4e-156f-4e01-a3c7-dd714d970113	f	71	2026-09-13 04:17:39.335027+00
eef5e6f3-adb7-4bc3-aa46-2e0ab680607e	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:17:39.338361+00	{"id": "certificate", "kind": "system", "name": "certificate"}	CertificateRegenerated	{"mocked": true, "policy_id": "00000000-0000-4000-8000-000000000101", "certificate": {"excess": {"currency": "AUD", "any_one_occurrence": 25000}, "product": "Marine Liability", "issued_at": "2026-09-13T04:17:39.336807+00:00", "policy_id": "00000000-0000-4000-8000-000000000101", "cover_types": [{"type": "Public Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}, {"type": "Products Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}], "effective_to": "2027-09-13T04:15:19.697990+00:00", "certificate_id": "749410fc-3ec4-484f-9d94-f49f5fd4d8bd", "effective_from": "2026-09-13T04:15:19.697990+00:00", "holder_display": "Harbour Marine Services Pty Ltd", "mocked_insurer": true, "insurer_display": "Fictional Carrier A", "territorial_limits": "Worldwide excl. USA/Canada"}, "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "qr_token_hash": "ccc522b9191f06ed63dc4e745a9068937d767981aff7c4c069380d53f330e696", "certificate_id": "749410fc-3ec4-484f-9d94-f49f5fd4d8bd", "effective_date": "2026-09-13T04:17:39.336807+00:00"}	{"certificate":{"certificate_id":"749410fc-3ec4-484f-9d94-f49f5fd4d8bd","cover_types":[{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Public Liability"},{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Products Liability"}],"effective_from":"2026-09-13T04:15:19.697990+00:00","effective_to":"2027-09-13T04:15:19.697990+00:00","excess":{"any_one_occurrence":25000,"currency":"AUD"},"holder_display":"Harbour Marine Services Pty Ltd","insurer_display":"Fictional Carrier A","issued_at":"2026-09-13T04:17:39.336807+00:00","mocked_insurer":true,"policy_id":"00000000-0000-4000-8000-000000000101","product":"Marine Liability","territorial_limits":"Worldwide excl. USA/Canada"},"certificate_id":"749410fc-3ec4-484f-9d94-f49f5fd4d8bd","effective_date":"2026-09-13T04:17:39.336807+00:00","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","qr_token_hash":"ccc522b9191f06ed63dc4e745a9068937d767981aff7c4c069380d53f330e696"}	4c3308993fd54ff298424914bc108e8737639a15f93648f472ac2dbc3f21865e	c9afd86ce7ca2c65267e073235ad3bdd423e08501574abb282958f30363d84e9	cert:regen:749410fc-3ec4-484f-9d94-f49f5fd4d8bd	t	72	2026-09-13 04:17:39.338212+00
ce67c943-ffb4-4f46-86cd-50fb609161eb	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:17:39.33948+00	{"id": "verifier", "kind": "system", "name": "verifier"}	VerifierTokenIssued	{"policy_id": "00000000-0000-4000-8000-000000000101", "expires_at": "2026-12-12T04:17:39.336807+00:00", "token_hash": "ccc522b9191f06ed63dc4e745a9068937d767981aff7c4c069380d53f330e696", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113", "certificate_id": "749410fc-3ec4-484f-9d94-f49f5fd4d8bd"}	{"certificate_id":"749410fc-3ec4-484f-9d94-f49f5fd4d8bd","envelope_id":"25516a4e-156f-4e01-a3c7-dd714d970113","expires_at":"2026-12-12T04:17:39.336807+00:00","policy_id":"00000000-0000-4000-8000-000000000101","token_hash":"ccc522b9191f06ed63dc4e745a9068937d767981aff7c4c069380d53f330e696"}	c9afd86ce7ca2c65267e073235ad3bdd423e08501574abb282958f30363d84e9	71b4c9a08ab0d88c0d8e5c37bdc0265820b75a287c33f9227305a50d463420c7	verifier:token:ccc522b9191f06ed63dc4e745a9068937d767981aff7c4c069380d53f330e696	f	73	2026-09-13 04:17:39.33935+00
7b5878ad-03e8-45dd-b13a-844fb79b1dcf	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:19:48.101641+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	ClientChangeRequested	{"client_id": "00000000-0000-4000-8000-000000000001", "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "raw_message": "Please raise our public liability from $10M to $20M."}	{"client_id":"00000000-0000-4000-8000-000000000001","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","policy_id":"00000000-0000-4000-8000-000000000101","raw_message":"Please raise our public liability from $10M to $20M."}	71b4c9a08ab0d88c0d8e5c37bdc0265820b75a287c33f9227305a50d463420c7	38baadbd90144e72f3073aab2954470aa1b40244e009cb9f27934c67b3ea628f	cchreq:c546b656-1aa6-45c8-9379-f5dd571f5843	f	81	2026-09-13 04:19:48.101257+00
455e3ce9-1897-4607-9fd1-358f71fe7251	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:19:48.104691+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationStarted	{"budget": {"max_wall_ms": 45000, "max_input_tokens": 4000, "max_output_tokens": 1500}, "class_key": "request_info", "agent_name": "intake", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"agent_name":"intake","budget":{"max_input_tokens":4000,"max_output_tokens":1500,"max_wall_ms":45000},"class_key":"request_info","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843"}	38baadbd90144e72f3073aab2954470aa1b40244e009cb9f27934c67b3ea628f	dc4facedc9add4598ed853aabd12bbc545e1e7bf1ba86d43ead7879c9d152e3a	aginv:start:c546b656-1aa6-45c8-9379-f5dd571f5843:intake	f	82	2026-09-13 04:19:48.104434+00
cecbf94e-8a6a-4b30-b631-d513ac50d627	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:19:53.893411+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentOutputProduced	{"flags": {"input_tokens_overrun": false}, "wall_ms": 5785, "decision": "propose", "citations": [{"ref": "schedule.limits.public_liability", "kind": "risk_schema"}], "class_key": "endorsement_execute_instructed_quoted", "agent_name": "intake", "confidence": {"scalar": 0.0, "components": {"completeness": 1.0, "class_agreement": 0.0, "schema_validity": 0.0, "citation_existence": 1.0}}, "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "tokens_used": {"input": 2282, "output": 333}}	{"agent_name":"intake","citations":[{"kind":"risk_schema","ref":"schedule.limits.public_liability"}],"class_key":"endorsement_execute_instructed_quoted","confidence":{"components":{"citation_existence":1,"class_agreement":0,"completeness":1,"schema_validity":0},"scalar":0},"decision":"propose","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","flags":{"input_tokens_overrun":false},"tokens_used":{"input":2282,"output":333},"wall_ms":5785}	dc4facedc9add4598ed853aabd12bbc545e1e7bf1ba86d43ead7879c9d152e3a	d9705215237828f350596e23ebf5a97254f6c23e74f3997a4ac4dde6e43f16ab	aginv:output:c546b656-1aa6-45c8-9379-f5dd571f5843:intake	f	83	2026-09-13 04:19:53.892229+00
ab170626-13ec-4293-83ed-dac34c56fbd6	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:15.265529+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentOutputProduced	{"flags": {"input_tokens_overrun": false}, "wall_ms": 21366, "decision": "propose", "citations": [{"ref": "cover_type:public_liability", "kind": "risk_schema"}], "class_key": "endorsement_execute_instructed_quoted", "agent_name": "placement", "confidence": {"scalar": 1.0, "components": {"completeness": 1.0, "class_agreement": 1.0, "schema_validity": 1.0, "citation_existence": 1.0}}, "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "tokens_used": {"input": 2606, "output": 1393}}	{"agent_name":"placement","citations":[{"kind":"risk_schema","ref":"cover_type:public_liability"}],"class_key":"endorsement_execute_instructed_quoted","confidence":{"components":{"citation_existence":1,"class_agreement":1,"completeness":1,"schema_validity":1},"scalar":1},"decision":"propose","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","flags":{"input_tokens_overrun":false},"tokens_used":{"input":2606,"output":1393},"wall_ms":21366}	a0188de5005c0050f7a40dffcc9a842c7a4eb2ce14b5cc6dab684e0fbb742b2b	4da5f600130b42134b024bbe00035499ef6bbac0ae9aaded53f3545462db327f	aginv:output:c546b656-1aa6-45c8-9379-f5dd571f5843:placement	f	86	2026-09-13 04:20:15.264396+00
28099151-05aa-4d5b-80d7-50a1a6a3b17a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:15.267639+00	{"id": "brain", "kind": "system", "name": "brain"}	AgentInvocationCompleted	{"outcome": "ok", "agent_name": "placement", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"agent_name":"placement","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","outcome":"ok"}	4da5f600130b42134b024bbe00035499ef6bbac0ae9aaded53f3545462db327f	c29f079b3d8d624dfbf6e648009f0fe65f0c5d28c15282f1967be43e2716e86b	aginv:done:c546b656-1aa6-45c8-9379-f5dd571f5843:placement	f	87	2026-09-13 04:20:15.267468+00
0ebc14d3-820b-4027-a197-ab8ba28a19e9	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:15.268691+00	{"id": "placement", "kind": "system", "name": "placement"}	SubmissionDrafted	{"mocked": false, "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "submission_summary": "Client requests an increase to the public liability any-one-occurrence limit under an existing Marine Liability policy. The aggregate limit is already at the requested level; the submission seeks carrier endorsement to align the any-one-occurrence sub-limit accordingly.", "structured_submission": {"cover_type": "public_liability", "market_targets": ["Fictional Carrier A"], "risk_description": "The insured holds a Marine Liability policy (policy ID 00000000-0000-4000-8000-000000000101) currently in force with Fictional Carrier A. The policy carries Public Liability and Products Liability covers, both with an aggregate of AUD 20,000,000 and a any-one-occurrence limit of AUD 10,000,000. The territorial scope is Worldwide excluding USA/Canada, with an any-one-occurrence excess of AUD 25,000. The client has requested an increase to the Public Liability any-one-occurrence limit to bring it in line with the existing aggregate limit.", "requested_changes": [{"citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.limits.public_liability"}, "to_value": 20000000, "operation": "increase", "field_path": "schedule.limits.public_liability", "from_value": 10000000}], "underwriter_questions_answered": [{"answer": "AUD 10,000,000 per the existing policy schedule.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.cover_types[0].limit_any_one"}, "question": "What is the current public liability any-one-occurrence limit?"}, {"answer": "AUD 20,000,000, as stated verbatim in the client message.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.limits.public_liability"}, "question": "What is the requested public liability any-one-occurrence limit?"}, {"answer": "AUD 20,000,000, which already matches the requested any-one-occurrence limit.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.cover_types[0].aggregate"}, "question": "What is the current public liability aggregate limit?"}, {"answer": "Worldwide excluding USA/Canada.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.territorial_limits"}, "question": "What are the territorial limits of the policy?"}, {"answer": "AUD 25,000 any one occurrence.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.excess.any_one_occurrence"}, "question": "What is the policy excess?"}, {"answer": "No reason for the increase was provided in the client message.", "citation": null, "question": "Has the client provided a reason for the limit increase?"}, {"answer": "The client request does not reference Products Liability; no change has been proposed for that sub-limit. This should be confirmed with the client.", "citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.cover_types[1].limit_any_one"}, "question": "Does the Products Liability any-one-occurrence limit require a corresponding change?"}]}, "recommended_wording_ref": "standard_marine_pl_v3"}	{"envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mocked":false,"policy_id":"00000000-0000-4000-8000-000000000101","recommended_wording_ref":"standard_marine_pl_v3","structured_submission":{"cover_type":"public_liability","market_targets":["Fictional Carrier A"],"requested_changes":[{"citation":{"field_path":"schedule.limits.public_liability","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"field_path":"schedule.limits.public_liability","from_value":10000000,"operation":"increase","to_value":20000000}],"risk_description":"The insured holds a Marine Liability policy (policy ID 00000000-0000-4000-8000-000000000101) currently in force with Fictional Carrier A. The policy carries Public Liability and Products Liability covers, both with an aggregate of AUD 20,000,000 and a any-one-occurrence limit of AUD 10,000,000. The territorial scope is Worldwide excluding USA/Canada, with an any-one-occurrence excess of AUD 25,000. The client has requested an increase to the Public Liability any-one-occurrence limit to bring it in line with the existing aggregate limit.","underwriter_questions_answered":[{"answer":"AUD 10,000,000 per the existing policy schedule.","citation":{"field_path":"schedule.cover_types[0].limit_any_one","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the current public liability any-one-occurrence limit?"},{"answer":"AUD 20,000,000, as stated verbatim in the client message.","citation":{"field_path":"schedule.limits.public_liability","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the requested public liability any-one-occurrence limit?"},{"answer":"AUD 20,000,000, which already matches the requested any-one-occurrence limit.","citation":{"field_path":"schedule.cover_types[0].aggregate","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the current public liability aggregate limit?"},{"answer":"Worldwide excluding USA/Canada.","citation":{"field_path":"schedule.territorial_limits","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What are the territorial limits of the policy?"},{"answer":"AUD 25,000 any one occurrence.","citation":{"field_path":"schedule.excess.any_one_occurrence","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"What is the policy excess?"},{"answer":"No reason for the increase was provided in the client message.","citation":null,"question":"Has the client provided a reason for the limit increase?"},{"answer":"The client request does not reference Products Liability; no change has been proposed for that sub-limit. This should be confirmed with the client.","citation":{"field_path":"schedule.cover_types[1].limit_any_one","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"question":"Does the Products Liability any-one-occurrence limit require a corresponding change?"}]},"submission_summary":"Client requests an increase to the public liability any-one-occurrence limit under an existing Marine Liability policy. The aggregate limit is already at the requested level; the submission seeks carrier endorsement to align the any-one-occurrence sub-limit accordingly."}	c29f079b3d8d624dfbf6e648009f0fe65f0c5d28c15282f1967be43e2716e86b	4481c76910b7e597402ea3401c303e67d13e5b7f393a3a1d8d68cc5ae8c8eb19	placement:submission:c546b656-1aa6-45c8-9379-f5dd571f5843	f	88	2026-09-13 04:20:15.268545+00
623d0ec2-e10c-49b8-b02d-6d346cb8a79a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:15.270162+00	{"id": "carrier_channel", "kind": "system", "name": "carrier"}	CarrierQuoted	{"terms": "Quote valid for 21 days. Subject to executed endorsement wording.", "mocked": true, "quote_id": "ec2f1778-8006-eaef-17f9-ce072ae41678", "policy_id": "00000000-0000-4000-8000-000000000101", "quoted_at": "2026-09-13T04:20:15.269979+00:00", "conditions": ["Certificate must be issued within 35 days of bind.", "Continuous cover confirmed — no gap since last renewal."], "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "carrier_name": "Fictional Carrier B", "premium_currency": "AUD", "premium_new_annual": "508500.00", "premium_change_amount": "500000.00"}	{"carrier_name":"Fictional Carrier B","conditions":["Certificate must be issued within 35 days of bind.","Continuous cover confirmed — no gap since last renewal."],"envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","premium_change_amount":"500000.00","premium_currency":"AUD","premium_new_annual":"508500.00","quote_id":"ec2f1778-8006-eaef-17f9-ce072ae41678","quoted_at":"2026-09-13T04:20:15.269979+00:00","terms":"Quote valid for 21 days. Subject to executed endorsement wording."}	4481c76910b7e597402ea3401c303e67d13e5b7f393a3a1d8d68cc5ae8c8eb19	48cb92aaa6e2bd89b27bd245f7a1d7be0ec792f10b40d8955f9b146b32e5a2b5	carrier:quote:c546b656-1aa6-45c8-9379-f5dd571f5843	t	89	2026-09-13 04:20:15.270015+00
b1bc940b-aeb9-47ca-9896-9bd0dad0124a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:15.271279+00	{"id": "orchestrator", "kind": "system", "name": "orchestrator"}	EndorsementQuoteReady	{"quote_id": "ec2f1778-8006-eaef-17f9-ce072ae41678", "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","policy_id":"00000000-0000-4000-8000-000000000101","quote_id":"ec2f1778-8006-eaef-17f9-ce072ae41678"}	48cb92aaa6e2bd89b27bd245f7a1d7be0ec792f10b40d8955f9b146b32e5a2b5	b2c91b0e3ff98516349e7e82e110e7f6562376ba14d19bc67ad70e8b7190e1f0	quote:ready:c546b656-1aa6-45c8-9379-f5dd571f5843	f	90	2026-09-13 04:20:15.271108+00
2fc12110-477f-442d-b593-73a6de97ca24	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:15.273603+00	{"id": "queue", "kind": "system", "name": "queue"}	QueueCardEnqueued	{"class_key": "endorsement_execute_instructed_quoted", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "confidence": 0.9, "hitl_since": "2026-09-13T04:20:15.272168+00:00", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "gate_reason": "quote_ready_operator_confirmation_required", "proposal_ref": "b1bc940b-aeb9-47ca-9896-9bd0dad0124a", "sla_deadline": "2026-09-14T04:20:15.272168+00:00", "routed_to_role": "principal"}	{"class_key":"endorsement_execute_instructed_quoted","client_id":"00000000-0000-4000-8000-000000000001","confidence":0.9,"envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","gate_reason":"quote_ready_operator_confirmation_required","hitl_since":"2026-09-13T04:20:15.272168+00:00","matter_id":null,"proposal_ref":"b1bc940b-aeb9-47ca-9896-9bd0dad0124a","routed_to_role":"principal","sla_deadline":"2026-09-14T04:20:15.272168+00:00"}	b2c91b0e3ff98516349e7e82e110e7f6562376ba14d19bc67ad70e8b7190e1f0	e742f8920d6fdf343055d136f5b00ade13fdf96ca5964f5c7e6a07ef370ef695	queue:enqueue:c546b656-1aa6-45c8-9379-f5dd571f5843	f	91	2026-09-13 04:20:15.273448+00
193f8aed-d9f8-4069-ad59-1d1d3447b35b	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:34.859773+00	{"id": "3eca1652-801e-44e5-84c2-7b6823a7d8dc", "kind": "human", "name": "principal"}	Approval	{"role": "principal", "user_id": "3eca1652-801e-44e5-84c2-7b6823a7d8dc", "decision": "approve", "class_key": "endorsement_execute_instructed_quoted", "policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"class_key":"endorsement_execute_instructed_quoted","decision":"approve","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","policy_id":"00000000-0000-4000-8000-000000000101","role":"principal","user_id":"3eca1652-801e-44e5-84c2-7b6823a7d8dc"}	e742f8920d6fdf343055d136f5b00ade13fdf96ca5964f5c7e6a07ef370ef695	c5d5ab66f1a435bac206e569d0a2d6b51078eb89ea29b42eaf1d775458b37c4d	appr:c546b656-1aa6-45c8-9379-f5dd571f5843:3eca1652-801e-44e5-84c2-7b6823a7d8dc:approve	f	92	2026-09-13 04:20:34.858856+00
5ad412c4-d743-4172-9eb6-0ae015beabb2	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.337484+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	PaymentMandateCreated	{"amount": "500000.00", "mocked": true, "status": "pending", "currency": "AUD", "client_id": "00000000-0000-4000-8000-000000000001", "policy_id": "00000000-0000-4000-8000-000000000101", "created_at": "2026-09-13T04:20:36.336987+00:00", "mandate_id": "f02947cc-b16e-46f9-d388-d037837e9753", "rail_label": "PayTo", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"amount":"500000.00","client_id":"00000000-0000-4000-8000-000000000001","created_at":"2026-09-13T04:20:36.336987+00:00","currency":"AUD","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mandate_id":"f02947cc-b16e-46f9-d388-d037837e9753","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","rail_label":"PayTo","status":"pending"}	c5d5ab66f1a435bac206e569d0a2d6b51078eb89ea29b42eaf1d775458b37c4d	395201dd1c3add9020c0bacf4fb130ea99a3d5edf55a4f6e5489514326953d81	payment:mandate:c546b656-1aa6-45c8-9379-f5dd571f5843	t	93	2026-09-13 04:20:36.337129+00
0db83f19-4f78-4d5f-ac9e-c3ee430a97ae	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.339064+00	{"id": "payment_rail", "kind": "system", "name": "payment"}	PaymentInitiated	{"amount": "500000.00", "mocked": true, "currency": "AUD", "policy_id": "00000000-0000-4000-8000-000000000101", "mandate_id": "f02947cc-b16e-46f9-d388-d037837e9753", "rail_label": "PayTo", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"amount":"500000.00","currency":"AUD","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mandate_id":"f02947cc-b16e-46f9-d388-d037837e9753","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","rail_label":"PayTo"}	395201dd1c3add9020c0bacf4fb130ea99a3d5edf55a4f6e5489514326953d81	1ad98780a6dcb9c6fcde32bd8255e054bf4900b7d125395a97e1f1c701498d6f	payment:initiated:c546b656-1aa6-45c8-9379-f5dd571f5843	t	94	2026-09-13 04:20:36.338909+00
21eb217e-289f-4da2-8cee-f0e7c8458a9a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.541086+00	{"id": "payment_rail", "kind": "system", "name": "payment"}	PaymentReceived	{"ref": "MOCK-PAYTO-b8267d36", "amount": "500000.00", "mocked": true, "status": "succeeded", "currency": "AUD", "quote_id": "ec2f1778-8006-eaef-17f9-ce072ae41678", "policy_id": "00000000-0000-4000-8000-000000000101", "mandate_id": "f02947cc-b16e-46f9-d388-d037837e9753", "payment_id": "5c338bf5-e91e-0823-e8d0-4180080858e9", "rail_label": "PayTo", "settled_at": "2026-09-13T04:20:36.540621+00:00", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843"}	{"amount":"500000.00","currency":"AUD","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mandate_id":"f02947cc-b16e-46f9-d388-d037837e9753","mocked":true,"payment_id":"5c338bf5-e91e-0823-e8d0-4180080858e9","policy_id":"00000000-0000-4000-8000-000000000101","quote_id":"ec2f1778-8006-eaef-17f9-ce072ae41678","rail_label":"PayTo","ref":"MOCK-PAYTO-b8267d36","settled_at":"2026-09-13T04:20:36.540621+00:00","status":"succeeded"}	1ad98780a6dcb9c6fcde32bd8255e054bf4900b7d125395a97e1f1c701498d6f	ca1f2ff14f1b149e5898e639a8b60a04634c496433b6f9950f8f013ca3beb479	payment:received:c546b656-1aa6-45c8-9379-f5dd571f5843	t	95	2026-09-13 04:20:36.540753+00
51238de7-959f-4e78-a406-1076285ed059	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.62411+00	{"id": "e_sign", "kind": "system", "name": "e_sign"}	SignatureRequested	{"mocked": true, "status": "sent", "policy_id": "00000000-0000-4000-8000-000000000101", "created_at": "2026-09-13T04:20:36.623688+00:00", "request_id": "eee41737-8442-7967-64ca-1dbbe266c4a4", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "document_ref": "endorsement:c546b656-1aa6-45c8-9379-f5dd571f5843", "signer_email": "debc6759-260c-4214-a0d6-1ce287dd3137@example.test"}	{"created_at":"2026-09-13T04:20:36.623688+00:00","document_ref":"endorsement:c546b656-1aa6-45c8-9379-f5dd571f5843","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","request_id":"eee41737-8442-7967-64ca-1dbbe266c4a4","signer_email":"debc6759-260c-4214-a0d6-1ce287dd3137@example.test","status":"sent"}	ca1f2ff14f1b149e5898e639a8b60a04634c496433b6f9950f8f013ca3beb479	bfa96fe15fba79180680b3ab6366c04083d9428182ae66cf90858cfa1b0e7cfb	esign:req:c546b656-1aa6-45c8-9379-f5dd571f5843	t	96	2026-09-13 04:20:36.623805+00
0cb5ee22-fbbb-4ddd-b9f4-9526f25a0831	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.776387+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	SignatureCompleted	{"mocked": true, "status": "signed", "policy_id": "00000000-0000-4000-8000-000000000101", "signed_at": "2026-09-13T04:20:36.775872+00:00", "request_id": "eee41737-8442-7967-64ca-1dbbe266c4a4", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "signature_id": "23409817-e206-4a47-62fd-985a1f9afc6a", "signature_blob_hash": "22922f833758efceea367e7ad11cd41b144f40a5f10133897bed78474b372b25"}	{"envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","request_id":"eee41737-8442-7967-64ca-1dbbe266c4a4","signature_blob_hash":"22922f833758efceea367e7ad11cd41b144f40a5f10133897bed78474b372b25","signature_id":"23409817-e206-4a47-62fd-985a1f9afc6a","signed_at":"2026-09-13T04:20:36.775872+00:00","status":"signed"}	bfa96fe15fba79180680b3ab6366c04083d9428182ae66cf90858cfa1b0e7cfb	1699cf4afb87f8b6a7b205607195c878aabee68263fa38482ea370a7bd2b1ab5	esign:sig:c546b656-1aa6-45c8-9379-f5dd571f5843	t	97	2026-09-13 04:20:36.776033+00
8ae9b4e8-1420-4255-85ad-81e43dc9da24	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.812027+00	{"id": "endorsement", "kind": "system", "name": "endorsement"}	EndorsementExecuted	{"policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "effective_date": "2026-09-13T04:20:36.810387+00:00", "endorsement_id": "5f448c76-b119-4d89-a51c-822b7c2ba561", "changes_applied": [{"citation": {"kind": "policy_schedule", "policy_id": "00000000-0000-4000-8000-000000000101", "field_path": "schedule.limits.public_liability"}, "to_value": 20000000, "operation": "increase", "field_path": "schedule.limits.public_liability", "from_value": 10000000}], "mocked_channels": ["carrier", "payment", "e_sign"]}	{"changes_applied":[{"citation":{"field_path":"schedule.limits.public_liability","kind":"policy_schedule","policy_id":"00000000-0000-4000-8000-000000000101"},"field_path":"schedule.limits.public_liability","from_value":10000000,"operation":"increase","to_value":20000000}],"effective_date":"2026-09-13T04:20:36.810387+00:00","endorsement_id":"5f448c76-b119-4d89-a51c-822b7c2ba561","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mocked_channels":["carrier","payment","e_sign"],"policy_id":"00000000-0000-4000-8000-000000000101"}	1699cf4afb87f8b6a7b205607195c878aabee68263fa38482ea370a7bd2b1ab5	e60c3b7d15751de0b2aa4942cf0619fc2c19156eab91a79f6333401ff71c375e	endorsement:exec:c546b656-1aa6-45c8-9379-f5dd571f5843	f	98	2026-09-13 04:20:36.811842+00
8a335eef-bc75-4161-b7be-4ec7cca79bce	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.813447+00	{"id": "endorsement", "kind": "system", "name": "endorsement"}	PolicyUpdated	{"policy_id": "00000000-0000-4000-8000-000000000101", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "endorsement_id": "5f448c76-b119-4d89-a51c-822b7c2ba561", "schedule_after": {"excess": {"currency": "AUD", "any_one_occurrence": 25000}, "limits": {"public_liability": 20000000}, "cover_types": [{"type": "Public Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}, {"type": "Products Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}], "territorial_limits": "Worldwide excl. USA/Canada"}}	{"endorsement_id":"5f448c76-b119-4d89-a51c-822b7c2ba561","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","policy_id":"00000000-0000-4000-8000-000000000101","schedule_after":{"cover_types":[{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Public Liability"},{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Products Liability"}],"excess":{"any_one_occurrence":25000,"currency":"AUD"},"limits":{"public_liability":20000000},"territorial_limits":"Worldwide excl. USA/Canada"}}	e60c3b7d15751de0b2aa4942cf0619fc2c19156eab91a79f6333401ff71c375e	def73601856da167fb1dd5a3ecb6cefc548df822a98a2fedff3ddceba567f95a	policy:updated:c546b656-1aa6-45c8-9379-f5dd571f5843	f	99	2026-09-13 04:20:36.8133+00
29ed7478-ed6b-4848-9a58-c630d9f8156f	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.816668+00	{"id": "certificate", "kind": "system", "name": "certificate"}	CertificateRegenerated	{"mocked": true, "policy_id": "00000000-0000-4000-8000-000000000101", "certificate": {"excess": {"currency": "AUD", "any_one_occurrence": 25000}, "product": "Marine Liability", "issued_at": "2026-09-13T04:20:36.815286+00:00", "policy_id": "00000000-0000-4000-8000-000000000101", "cover_types": [{"type": "Public Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}, {"type": "Products Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}], "effective_to": "2027-09-13T04:15:19.697990+00:00", "certificate_id": "3e272eca-8f3b-49e4-8153-a42d27e5033e", "effective_from": "2026-09-13T04:15:19.697990+00:00", "holder_display": "Harbour Marine Services Pty Ltd", "mocked_insurer": true, "insurer_display": "Fictional Carrier A", "territorial_limits": "Worldwide excl. USA/Canada"}, "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "qr_token_hash": "9974f73b3cdf48e891cba7a586d325dbde1775762c16d98a7294f8dbc52577c1", "certificate_id": "3e272eca-8f3b-49e4-8153-a42d27e5033e", "effective_date": "2026-09-13T04:20:36.815286+00:00"}	{"certificate":{"certificate_id":"3e272eca-8f3b-49e4-8153-a42d27e5033e","cover_types":[{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Public Liability"},{"aggregate":20000000,"currency":"AUD","limit_any_one":10000000,"type":"Products Liability"}],"effective_from":"2026-09-13T04:15:19.697990+00:00","effective_to":"2027-09-13T04:15:19.697990+00:00","excess":{"any_one_occurrence":25000,"currency":"AUD"},"holder_display":"Harbour Marine Services Pty Ltd","insurer_display":"Fictional Carrier A","issued_at":"2026-09-13T04:20:36.815286+00:00","mocked_insurer":true,"policy_id":"00000000-0000-4000-8000-000000000101","product":"Marine Liability","territorial_limits":"Worldwide excl. USA/Canada"},"certificate_id":"3e272eca-8f3b-49e4-8153-a42d27e5033e","effective_date":"2026-09-13T04:20:36.815286+00:00","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","mocked":true,"policy_id":"00000000-0000-4000-8000-000000000101","qr_token_hash":"9974f73b3cdf48e891cba7a586d325dbde1775762c16d98a7294f8dbc52577c1"}	def73601856da167fb1dd5a3ecb6cefc548df822a98a2fedff3ddceba567f95a	8eeefa03f1f4e042b38630780bf5922a09df683d04e363ecacdbfe16120bf1bd	cert:regen:3e272eca-8f3b-49e4-8153-a42d27e5033e	t	100	2026-09-13 04:20:36.816501+00
2a4d049e-8337-4e67-94b2-786fc4b660b7	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:20:36.818024+00	{"id": "verifier", "kind": "system", "name": "verifier"}	VerifierTokenIssued	{"policy_id": "00000000-0000-4000-8000-000000000101", "expires_at": "2026-12-12T04:20:36.815286+00:00", "token_hash": "9974f73b3cdf48e891cba7a586d325dbde1775762c16d98a7294f8dbc52577c1", "envelope_id": "c546b656-1aa6-45c8-9379-f5dd571f5843", "certificate_id": "3e272eca-8f3b-49e4-8153-a42d27e5033e"}	{"certificate_id":"3e272eca-8f3b-49e4-8153-a42d27e5033e","envelope_id":"c546b656-1aa6-45c8-9379-f5dd571f5843","expires_at":"2026-12-12T04:20:36.815286+00:00","policy_id":"00000000-0000-4000-8000-000000000101","token_hash":"9974f73b3cdf48e891cba7a586d325dbde1775762c16d98a7294f8dbc52577c1"}	8eeefa03f1f4e042b38630780bf5922a09df683d04e363ecacdbfe16120bf1bd	588871b253be989020057028da5705131ebcb606383683fd3061f4c5cb4ad66b	verifier:token:9974f73b3cdf48e891cba7a586d325dbde1775762c16d98a7294f8dbc52577c1	f	101	2026-09-13 04:20:36.817873+00
c92fdf6f-ae33-467a-b6f2-fc54347255db	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:31:01.080878+00	{"id": "debc6759-260c-4214-a0d6-1ce287dd3137", "kind": "human", "name": "client_owner"}	ClientQuestionAsked	{"message": "When does my Marine Liability renew again?", "client_id": "00000000-0000-4000-8000-000000000001", "envelope_id": "1c526bd5-4b6e-4c0e-9a03-7c523bc0eb67"}	{"client_id":"00000000-0000-4000-8000-000000000001","envelope_id":"1c526bd5-4b6e-4c0e-9a03-7c523bc0eb67","message":"When does my Marine Liability renew again?"}	588871b253be989020057028da5705131ebcb606383683fd3061f4c5cb4ad66b	177a9734bb1e83d807c1e55281c72cd6016cff08b1c452bc19c7bdae0d47ae50	ask:in:1c526bd5-4b6e-4c0e-9a03-7c523bc0eb67	f	144	2026-09-13 04:31:01.08069+00
16296cff-587a-4b04-9060-05489f7c7c7a	e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13 04:31:09.849628+00	{"id": "release", "kind": "system", "name": "release"}	ClientMessageReleased	{"draft": "We don't have your Marine Liability policy details on file in this system just yet, so I'm not able to give you the exact renewal date right now. Your broker, BurMac Insurance Brokers Pty Ltd, will be able to pull that up straight away.", "message": "We don't have your Marine Liability policy details on file in this system just yet, so I'm not able to give you the exact renewal date right now. Your broker, BurMac Insurance Brokers Pty Ltd, will be able to pull that up straight away.", "client_id": "00000000-0000-4000-8000-000000000001", "matter_id": null, "envelope_id": "1c526bd5-4b6e-4c0e-9a03-7c523bc0eb67", "author_agent": "liaison", "risks_flagged": [], "classification": "factual", "classifier_verdict": {"_wall_ms": 4555, "_tokens_used": {"input": 2382, "output": 179}, "risks_flagged": [], "release_verdict": "release", "recommended_rewrite": null, "advice_classification": "factual", "classification_rationale": "The draft simply explains a system limitation (policy details not on file), declines to speculate on the renewal date, and redirects the client to their broker. No coverage position is stated, no premium is estimated, and no specific broker action is recommended. The tone is purely informational."}, "classifier_rationale": "The draft simply explains a system limitation (policy details not on file), declines to speculate on the renewal date, and redirects the client to their broker. No coverage position is stated, no premium is estimated, and no specific broker action is recommended. The tone is purely informational.", "mocked_channels_used": []}	{"author_agent":"liaison","classification":"factual","classifier_rationale":"The draft simply explains a system limitation (policy details not on file), declines to speculate on the renewal date, and redirects the client to their broker. No coverage position is stated, no premium is estimated, and no specific broker action is recommended. The tone is purely informational.","classifier_verdict":{"_tokens_used":{"input":2382,"output":179},"_wall_ms":4555,"advice_classification":"factual","classification_rationale":"The draft simply explains a system limitation (policy details not on file), declines to speculate on the renewal date, and redirects the client to their broker. No coverage position is stated, no premium is estimated, and no specific broker action is recommended. The tone is purely informational.","recommended_rewrite":null,"release_verdict":"release","risks_flagged":[]},"client_id":"00000000-0000-4000-8000-000000000001","draft":"We don't have your Marine Liability policy details on file in this system just yet, so I'm not able to give you the exact renewal date right now. Your broker, BurMac Insurance Brokers Pty Ltd, will be able to pull that up straight away.","envelope_id":"1c526bd5-4b6e-4c0e-9a03-7c523bc0eb67","matter_id":null,"message":"We don't have your Marine Liability policy details on file in this system just yet, so I'm not able to give you the exact renewal date right now. Your broker, BurMac Insurance Brokers Pty Ltd, will be able to pull that up straight away.","mocked_channels_used":[],"risks_flagged":[]}	177a9734bb1e83d807c1e55281c72cd6016cff08b1c452bc19c7bdae0d47ae50	fc6467429d4eb1f4f6d3ed99c2e3299ec622f0c5687073bd6eb215da1fd31d1c	clientmsg:release:1c526bd5-4b6e-4c0e-9a03-7c523bc0eb67	f	145	2026-09-13 04:31:09.848499+00
\.


--
-- Data for Name: magic_link_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.magic_link_tokens (token_hash, user_id, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policies (policy_id, tenant_id, client_id, status, product, insurer_display, inception, expiry, premium_amount, premium_currency, schedule, imported_from, created_at) FROM stdin;
00000000-0000-4000-8000-000000000102	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000001	tracked	Cyber	Fictional Carrier B	2026-07-15 04:15:19.700466+00	2027-07-15 04:15:19.700466+00	2200.00	AUD	{"excess": {"currency": "AUD", "any_one_claim": 10000}, "cover_types": [{"type": "Cyber Liability", "currency": "AUD", "aggregate": 2000000, "limit_any_one": 2000000}], "territorial_limits": "Australia only"}	manual_entry_burmac	2026-09-13 04:15:19.70049+00
00000000-0000-4000-8000-000000000103	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000003	managed	Marine Cargo	Fictional Carrier B	2026-09-13 04:15:19.756821+00	2027-09-13 04:15:19.756821+00	4200.00	AUD	{"excess": {"currency": "AUD", "any_one_occurrence": 10000}, "cover_types": [{"type": "Marine Cargo", "currency": "AUD", "aggregate": 15000000, "limit_any_one": 5000000}], "territorial_limits": "Worldwide"}	\N	2026-09-13 04:15:19.756843+00
00000000-0000-4000-8000-000000000101	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000001	managed	Marine Liability	Fictional Carrier A	2026-09-13 04:15:19.69799+00	2027-09-13 04:15:19.69799+00	8500.00	AUD	{"excess": {"currency": "AUD", "any_one_occurrence": 25000}, "limits": {"public_liability": 20000000}, "cover_types": [{"type": "Public Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}, {"type": "Products Liability", "currency": "AUD", "aggregate": 20000000, "limit_any_one": 10000000}], "territorial_limits": "Worldwide excl. USA/Canada"}	\N	2026-09-13 04:15:19.698016+00
\.


--
-- Data for Name: proj_active_blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_active_blocks (tenant_id, block_id, target_kind, target_id, reason, created_at, cleared_at, cleared_reason, added_by_event, cleared_by_event) FROM stdin;
\.


--
-- Data for Name: proj_class_unlock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_class_unlock (tenant_id, class_key, decisions_seen, agreements, eno_misses, unlocked, unlocked_at, last_relock_at, last_relock_reason, updated_by_event) FROM stdin;
e73e7029-da66-4659-9ac8-845f22b1f8a5	structure_risk	22	14	1	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	endorsement_standard	21	17	0	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	claim_admin	40	26	1	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	certificate_issue	24	15	2	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	renewal_pack_unchanged	35	22	2	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	comms_service	20	14	1	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	request_info	32	20	0	f	\N	\N	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	submit_to_market	25	20	0	f	\N	\N	\N	\N
\.


--
-- Data for Name: proj_kpi_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_kpi_daily (tenant_id, day, kpi_id, value_scalar, value_meta, delta_prev, spark_series, computed_at) FROM stdin;
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	1	12700.0000	{"unit": "AUD", "label": "Book", "by_product": {"Marine Cargo": 4200.0, "Marine Liability": 8500.0}, "managed_count": 2}	\N	{12700.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	2	1270.0000	{"unit": "AUD", "label": "Income per client", "fees_total": 0.0, "commission_rate": 0.2, "commission_total": 2540.0, "active_client_count": 2, "mocked_commission_rate": true}	\N	{1270.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	3	0.0000	{"unit": "%", "label": "Retention rate", "reason": "no renewal events yet — awaits phase 8+", "renewed_count": 0, "renewed_value": 0.0, "not_yet_measurable": true}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	4	0.0000	{"unit": "days", "label": "Pipeline velocity", "reason": "no pipeline events yet — awaits phase 8+", "stages": {}, "conversion": {}, "not_yet_measurable": true}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	5	0.0000	{"unit": "seconds", "label": "Response time", "events": [], "reason": "no resolved queue cards yet", "drillable": true, "sample_size": 0, "median_by_class": {}, "not_yet_measurable": true}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	6	0.0000	{"unit": "hours", "label": "Time to quote", "reason": "no endorsement→quote pairs yet — awaits phase 8 endorsement scene", "sample_size": 0, "median_hours": 0.0, "not_yet_measurable": true}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	7	0.0000	{"met": 0, "unit": "%", "label": "Claims timeframe compliance", "missed": 0, "reason": "no claim events yet — awaits phase 9 claim scene", "not_yet_measurable": true}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	9	0.0000	{"unit": "tokens/matter", "label": "Cost per matter", "reason": "no matters yet", "invocations": 7, "tokens_used": 6724, "matter_count": 0, "human_minutes": 0.0, "compute_seconds": 0.0, "not_yet_measurable": true}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	10	6.2000	{"unit": "approvals/person", "label": "Approvals load", "by_day": {"2026-09-13": 31}, "events": [{"ts": "2026-09-13T04:15:19.705915+00:00", "role": "principal", "user_id": "principal", "decision": "reject", "envelope_id": "2b8de58c-83be-5c66-b80d-2b130a27744f"}, {"ts": "2026-09-13T04:15:19.707249+00:00", "role": "principal", "user_id": "principal", "decision": "approve", "envelope_id": "573a1085-e49c-5cbc-a973-50d618d3daf9"}, {"ts": "2026-09-13T04:15:19.708367+00:00", "role": "compliance", "user_id": "compliance", "decision": "reject", "envelope_id": "31344167-3e62-5c2a-81de-ab683834e96e"}, {"ts": "2026-09-13T04:15:19.709669+00:00", "role": "accounts", "user_id": "accounts-b", "decision": "approve", "envelope_id": "dbfab3f0-88bb-5608-8cb7-b2db40511005"}, {"ts": "2026-09-13T04:15:19.711003+00:00", "role": "principal", "user_id": "principal", "decision": "approve", "envelope_id": "90207b26-68d0-571b-a902-66f1a5034def"}, {"ts": "2026-09-13T04:15:19.712045+00:00", "role": "principal", "user_id": "principal", "decision": "reject", "envelope_id": "c5f45d5f-aaad-540f-bcfb-c4640221b8ac"}, {"ts": "2026-09-13T04:15:19.713170+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "705a4fc0-ca2b-5a6b-9863-d48a5186c2e5"}, {"ts": "2026-09-13T04:15:19.714308+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "12c941a4-5da6-5f1d-9b5a-c569275961db"}, {"ts": "2026-09-13T04:15:19.715381+00:00", "role": "accounts", "user_id": "accounts-b", "decision": "approve", "envelope_id": "e55a5d8b-fc43-5737-b2ed-f42bd3f98940"}, {"ts": "2026-09-13T04:15:19.716442+00:00", "role": "accounts", "user_id": "accounts-b", "decision": "reject", "envelope_id": "61bf0fb8-7f8b-5a82-9d94-f07c37024c2e"}, {"ts": "2026-09-13T04:15:19.717506+00:00", "role": "compliance", "user_id": "compliance", "decision": "reject", "envelope_id": "cc994d10-5c2e-543f-9b04-4d26c77fa0ce"}, {"ts": "2026-09-13T04:15:19.718561+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "bf0c5689-4630-595a-9a92-02599de7423e"}, {"ts": "2026-09-13T04:15:19.719574+00:00", "role": "compliance", "user_id": "compliance", "decision": "reject", "envelope_id": "dcec3fce-cb40-5a69-b76a-f9bed6bc4433"}, {"ts": "2026-09-13T04:15:19.720551+00:00", "role": "principal", "user_id": "principal", "decision": "approve", "envelope_id": "50f85cb9-4670-5f07-8637-66d27ab6c31a"}, {"ts": "2026-09-13T04:15:19.721532+00:00", "role": "compliance", "user_id": "compliance", "decision": "approve", "envelope_id": "15a990e9-2c1d-5d70-8404-8bec7097807d"}, {"ts": "2026-09-13T04:15:19.722523+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "63e4d6a4-6ef4-51bd-9eba-940a3ebe1921"}, {"ts": "2026-09-13T04:15:19.723467+00:00", "role": "principal", "user_id": "principal", "decision": "approve", "envelope_id": "ceedf714-c286-5312-893b-99333620c324"}, {"ts": "2026-09-13T04:15:19.724530+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "d22c1f92-5cd6-542c-a412-e609346f720f"}, {"ts": "2026-09-13T04:15:19.725632+00:00", "role": "principal", "user_id": "principal", "decision": "approve", "envelope_id": "05e534dd-8407-5ba4-bd70-2dec8e37ec5a"}, {"ts": "2026-09-13T04:15:19.726719+00:00", "role": "compliance", "user_id": "compliance", "decision": "reject", "envelope_id": "d0a028aa-1587-5bcc-9a22-e03e57bf69ea"}, {"ts": "2026-09-13T04:15:19.727740+00:00", "role": "compliance", "user_id": "compliance", "decision": "approve", "envelope_id": "d4a398da-d738-5fc3-b2e8-041a83aa569b"}, {"ts": "2026-09-13T04:15:19.728703+00:00", "role": "compliance", "user_id": "compliance", "decision": "reject", "envelope_id": "00104d57-6a3a-5c4d-a5a3-a9943008b9e3"}, {"ts": "2026-09-13T04:15:19.729773+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "reject", "envelope_id": "b31c6c75-af29-549e-bd99-23d35db526e9"}, {"ts": "2026-09-13T04:15:19.730812+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "3b92d506-376c-569e-9ea1-681bfb18b518"}, {"ts": "2026-09-13T04:15:19.731751+00:00", "role": "accounts", "user_id": "accounts-b", "decision": "approve", "envelope_id": "e5839f9d-7ece-56ec-b8b3-97eeb43e89bd"}, {"ts": "2026-09-13T04:15:19.732801+00:00", "role": "compliance", "user_id": "compliance", "decision": "approve", "envelope_id": "af92d0e7-3966-517e-869a-f22c45d5a6d8"}, {"ts": "2026-09-13T04:15:19.733736+00:00", "role": "compliance", "user_id": "compliance", "decision": "reject", "envelope_id": "d255997c-7ee4-5cd2-a06e-2dfff71e1d36"}, {"ts": "2026-09-13T04:15:19.734683+00:00", "role": "principal", "user_id": "principal", "decision": "approve", "envelope_id": "dfef6a46-4dec-5c8c-bd4d-e7d5518a5229"}, {"ts": "2026-09-13T04:15:19.735694+00:00", "role": "accounts", "user_id": "accounts-a", "decision": "approve", "envelope_id": "59d34968-f1d8-5b1d-ba9e-c9f767a2e068"}, {"ts": "2026-09-13T04:15:19.736728+00:00", "role": "compliance", "user_id": "compliance", "decision": "approve", "envelope_id": "37ad5833-33eb-50ae-bb59-93e479a2a189"}, {"ts": "2026-09-13T04:16:56.872543+00:00", "role": "principal", "user_id": "3eca1652-801e-44e5-84c2-7b6823a7d8dc", "decision": "approve", "envelope_id": "25516a4e-156f-4e01-a3c7-dd714d970113"}], "drillable": true, "sample_size": 31, "per_user_count": {"principal": 8, "accounts-a": 8, "accounts-b": 4, "compliance": 10, "3eca1652-801e-44e5-84c2-7b6823a7d8dc": 1}}	\N	{6.2}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	11	100.0000	{"unit": "%", "label": "Compliance health", "events": [], "reason": "no compliance events yet; treating as clean", "breaches": 0, "drillable": true, "open_blocks": 0, "complaints_open": 0, "complaints_within_timeframe_pct": 0.0}	\N	{100.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	12	0.0000	{"unit": "AUD", "label": "Cash", "reason": "finance module out of scope for this build", "trust_exceptions": 0, "not_yet_measurable": true, "unremitted_premium": 0.0, "receivables_over_30": 0.0}	\N	{0.0}	2026-09-13 04:17:45.843445+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	2026-09-13	8	67.5799	{"unit": "%", "label": "Autonomous %", "drillable": true, "per_class": {"claim_admin": {"unlocked": false, "agreements": 26, "eno_misses": 1, "agreement_pct": 65.0, "decisions_seen": 40}, "request_info": {"unlocked": false, "agreements": 20, "eno_misses": 0, "agreement_pct": 62.5, "decisions_seen": 32}, "comms_service": {"unlocked": false, "agreements": 14, "eno_misses": 1, "agreement_pct": 70.0, "decisions_seen": 20}, "structure_risk": {"unlocked": false, "agreements": 14, "eno_misses": 1, "agreement_pct": 63.63636363636363, "decisions_seen": 22}, "submit_to_market": {"unlocked": false, "agreements": 20, "eno_misses": 0, "agreement_pct": 80.0, "decisions_seen": 25}, "certificate_issue": {"unlocked": false, "agreements": 15, "eno_misses": 2, "agreement_pct": 62.5, "decisions_seen": 24}, "endorsement_standard": {"unlocked": false, "agreements": 17, "eno_misses": 0, "agreement_pct": 80.95238095238095, "decisions_seen": 21}, "renewal_pack_unchanged": {"unlocked": false, "agreements": 22, "eno_misses": 2, "agreement_pct": 62.857142857142854, "decisions_seen": 35}}, "total_decisions": 219, "total_agreements": 148}	\N	{67.57990867579909}	2026-09-13 04:17:45.843445+00
\.


--
-- Data for Name: proj_matters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_matters (tenant_id, matter_id, client_id, status, subject, updated_at, updated_by_event) FROM stdin;
\.


--
-- Data for Name: proj_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_queue (tenant_id, envelope_id, matter_id, client_id, class_key, proposal_ref, hitl_since, sla_deadline, gate_reason, confidence, routed_to_role, resolved_at, resolved_by_event) FROM stdin;
e73e7029-da66-4659-9ac8-845f22b1f8a5	7f23ec7b-0606-5169-9599-4082b6484593	\N	00000000-0000-4000-8000-000000000001	certificate_issue	2bb3d1b2-d888-4d48-a077-b44e93f1a176	2026-09-12 23:15:19.738911+00	2026-09-13 03:15:19.738911+00	non_standard_wording	0.791	principal	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	44bc4212-d962-56ce-83d8-1c4ca5342913	\N	00000000-0000-4000-8000-000000000001	structure_risk	7b513c09-8546-46bd-9128-4c541e8b4008	2026-09-12 23:15:19.738911+00	2026-09-13 03:15:19.738911+00	hitl_predicate matched	0.714	principal	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	9489ea6c-f581-502f-8683-226dd95fd673	\N	00000000-0000-4000-8000-000000000001	claim_admin	e588b50d-fbea-428f-a293-c977d680ccf0	2026-09-12 21:15:19.738911+00	2026-09-13 05:15:19.738911+00	coverage_language_detected	0.794	principal	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	6f410c2c-737a-54e9-af9e-ac4917c33a92	\N	00000000-0000-4000-8000-000000000001	endorsement_execute_instructed_quoted	700508fa-c83c-42b9-88a4-c6b6bdb48018	2026-09-12 05:15:19.738911+00	2026-09-13 05:15:19.738911+00	ambiguous_reply	0.762	principal	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	ffd21553-fd55-5cee-9075-5be95befa632	\N	00000000-0000-4000-8000-000000000001	submit_to_market	0128ad01-42ec-4966-a18f-cbdade366882	2026-09-13 04:14:19.738911+00	2026-09-14 04:14:19.738911+00	new_business	0.692	accounts	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	25516a4e-156f-4e01-a3c7-dd714d970113	\N	00000000-0000-4000-8000-000000000001	endorsement_execute_instructed_quoted	610be08f-2ae1-466f-9f1b-d53f9ea0a57b	2026-09-13 04:16:03.995429+00	2026-09-14 04:16:03.995429+00	quote_ready_operator_confirmation_required	0.900	principal	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	3abf9d00-8bd8-47a5-8a57-d6ca7edebc47	\N	00000000-0000-4000-8000-000000000003	comms_service	afbe87cb-e4bc-417c-aa3b-c3181669ca31	2026-09-13 04:16:56.875974+00	2026-09-14 04:16:56.875974+00	vulnerable_flag_set	\N	account_executive	\N	\N
e73e7029-da66-4659-9ac8-845f22b1f8a5	c546b656-1aa6-45c8-9379-f5dd571f5843	\N	00000000-0000-4000-8000-000000000001	endorsement_execute_instructed_quoted	b1bc940b-aeb9-47ca-9896-9bd0dad0124a	2026-09-13 04:20:15.272168+00	2026-09-14 04:20:15.272168+00	quote_ready_operator_confirmation_required	0.900	principal	\N	\N
\.


--
-- Data for Name: proj_sprint_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_sprint_usage (tenant_id, tokens_used, invocations, last_alert_pct, updated_by_event) FROM stdin;
e73e7029-da66-4659-9ac8-845f22b1f8a5	13338	9	0	ab170626-13ec-4293-83ed-dac34c56fbd6
\.


--
-- Data for Name: proj_sprint_usage_by_agent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_sprint_usage_by_agent (tenant_id, agent_name, tokens_used_input, tokens_used_output, invocations, first_seen, last_seen) FROM stdin;
e73e7029-da66-4659-9ac8-845f22b1f8a5	intake	4571	674	2	2026-09-13 04:15:40.746684+00	2026-09-13 04:19:53.892229+00
e73e7029-da66-4659-9ac8-845f22b1f8a5	placement	5200	2893	2	2026-09-13 04:16:03.987342+00	2026-09-13 04:20:15.264396+00
\.


--
-- Data for Name: proj_workflow_waits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proj_workflow_waits (tenant_id, workflow_id, step, resume_predicate, fire_at, timeout_at, resolved, resolved_at, updated_by_event) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (session_id, user_id, tenant_id, brokerage_id, client_id, active_role, mfa_verified, expires_at, revoked_at, created_at, client_prefs) FROM stdin;
2fc08a47-4e61-45a1-b60d-19b4941fdf1a	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:15:35.924531+00	\N	2026-09-13 04:15:35.924566+00	{}
c299f99d-d5e2-46b7-a9a1-cc4f64812786	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:16:25.598653+00	\N	2026-09-13 04:16:25.598694+00	{}
59f3af05-14cc-4ab9-b6e6-b343a4745fdb	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:17:39.320001+00	\N	2026-09-13 04:17:39.320038+00	{}
74520423-1466-4e8d-a076-e19ede20f4aa	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:17:40.296754+00	\N	2026-09-13 04:17:40.296791+00	{}
8e6d3271-4941-4354-95c9-e9f425a32681	3eca1652-801e-44e5-84c2-7b6823a7d8dc	e73e7029-da66-4659-9ac8-845f22b1f8a5	db12fced-8abd-4542-a379-152aa5164e8d	\N	principal	t	2026-09-13 16:17:45.798016+00	\N	2026-09-13 04:17:45.79806+00	{}
e62c6505-94dd-40bd-8260-b6200deb7477	3eca1652-801e-44e5-84c2-7b6823a7d8dc	e73e7029-da66-4659-9ac8-845f22b1f8a5	db12fced-8abd-4542-a379-152aa5164e8d	\N	principal	t	2026-09-13 16:18:57.277627+00	\N	2026-09-13 04:18:57.277657+00	{}
d8c901f5-3277-47e5-9a8d-433398d8aedf	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:19:48.088632+00	\N	2026-09-13 04:19:48.088659+00	{}
a5886693-aa4f-4332-8fda-4fe2a7565798	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:20:35.266878+00	\N	2026-09-13 04:20:35.266917+00	{}
49272744-7287-494a-9c7b-c42adc607f6d	debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	\N	00000000-0000-4000-8000-000000000001	client_owner	t	2026-09-13 16:30:59.118221+00	\N	2026-09-13 04:30:59.118247+00	{}
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (tenant_id, slug, display_name, genesis_hash, created_at) FROM stdin;
e73e7029-da66-4659-9ac8-845f22b1f8a5	burmac	BurMac Insurance Brokers	de03f43f66c387acb8a73a804f58434e0fffb7fe8a7c493e9c35604221719f1a	2026-09-13 04:15:19.398094+00
\.


--
-- Data for Name: user_brokerage_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_brokerage_roles (user_id, brokerage_id, role, active, created_at) FROM stdin;
3eca1652-801e-44e5-84c2-7b6823a7d8dc	db12fced-8abd-4542-a379-152aa5164e8d	principal	t	2026-09-13 04:15:19.446808+00
78d75117-6eec-4a7e-bb62-b465cd5f7b00	db12fced-8abd-4542-a379-152aa5164e8d	deputy	t	2026-09-13 04:15:19.486761+00
f5fad6a9-9602-4797-999f-91a86b7cb7fa	db12fced-8abd-4542-a379-152aa5164e8d	ae	t	2026-09-13 04:15:19.527251+00
1cd636b1-21f6-4d0e-8625-a934b70e5d7e	db12fced-8abd-4542-a379-152aa5164e8d	accounts	t	2026-09-13 04:15:19.567931+00
383f7437-b0c9-48f5-b791-3b1edcb7f7fd	db12fced-8abd-4542-a379-152aa5164e8d	accounts	t	2026-09-13 04:15:19.607541+00
91623863-43f4-4f80-8f01-9b28122235d8	db12fced-8abd-4542-a379-152aa5164e8d	compliance	t	2026-09-13 04:15:19.647453+00
e7000464-8d99-4540-b0db-3cf9969bd787	db12fced-8abd-4542-a379-152aa5164e8d	auditor	t	2026-09-13 04:15:19.68831+00
\.


--
-- Data for Name: user_client_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_client_links (user_id, tenant_id, client_id, role, created_at) FROM stdin;
debc6759-260c-4214-a0d6-1ce287dd3137	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000001	client_owner	2026-09-13 04:15:19.690148+00
a829122e-a7fe-4b88-9065-9101074c71ab	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000001	client_finance	2026-09-13 04:15:19.692089+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, email, display_name, kind, password_hash, mfa_secret, created_at) FROM stdin;
3eca1652-801e-44e5-84c2-7b6823a7d8dc	principal@burmac.example	Ada Principal	operator	$argon2id$v=19$m=65536,t=3,p=4$+Z/TLdWDgBmusKe7JiNfmA$P1LdTgdpX1icadwKXvJuqKvsnBHfjVP+SrgaxeLOxrQ	\N	2026-09-13 04:15:19.445624+00
78d75117-6eec-4a7e-bb62-b465cd5f7b00	deputy@burmac.example	Ben Deputy	operator	$argon2id$v=19$m=65536,t=3,p=4$gUObejcVSG9HZjlGgZbWGQ$MPBP0m7mKWDLemLP5sjN0L/RhUIqGzXbBTv11RanJTo	\N	2026-09-13 04:15:19.485767+00
f5fad6a9-9602-4797-999f-91a86b7cb7fa	ae@burmac.example	Cass Executive	operator	$argon2id$v=19$m=65536,t=3,p=4$ZxBSkn4KKI4lxerScMErog$m6MiEmmfEJLseqyQy+Lv9uRMSIkHfU6JsOAP8zVHHjo	\N	2026-09-13 04:15:19.526289+00
1cd636b1-21f6-4d0e-8625-a934b70e5d7e	accounts-a@burmac.example	Dee Accounts	operator	$argon2id$v=19$m=65536,t=3,p=4$KxMNjXUmlM8zot+a3Esbng$iuAoAy2jNJyihma7hpcDzLqB/K7DQtJCj1CF1IFK3tU	\N	2026-09-13 04:15:19.56683+00
383f7437-b0c9-48f5-b791-3b1edcb7f7fd	accounts-b@burmac.example	Ev Accounts	operator	$argon2id$v=19$m=65536,t=3,p=4$xeHZAYPjAjIcY0tk4wtFxQ$UQgOaob2QpyKWN/9LpOPmU/JZz0TFLOnotdMyoVXsQQ	\N	2026-09-13 04:15:19.606534+00
91623863-43f4-4f80-8f01-9b28122235d8	compliance@burmac.example	Fin Compliance	operator	$argon2id$v=19$m=65536,t=3,p=4$MT91A2HhKpsJu0m8e72PyA$R0LheOEjEpb93sn1qfER4B2hojoCEGkGgbMLj9EeNdM	\N	2026-09-13 04:15:19.646451+00
e7000464-8d99-4540-b0db-3cf9969bd787	auditor@burmac.example	Gil Auditor	operator	$argon2id$v=19$m=65536,t=3,p=4$2/Z8re+Sb5v2OF7oSF7a9Q$zhTfu9uW3Fj2BXQ/8iqmLzXxjs2sZ5qDlPoqXtUGxxY	\N	2026-09-13 04:15:19.687335+00
debc6759-260c-4214-a0d6-1ce287dd3137	owner@fictionalclient.example	Kai Owner	client	\N	\N	2026-09-13 04:15:19.689342+00
a829122e-a7fe-4b88-9065-9101074c71ab	finance@fictionalclient.example	Sam Finance	client	\N	\N	2026-09-13 04:15:19.691405+00
\.


--
-- Data for Name: verifier_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verifier_tokens (token_hash, tenant_id, policy_id, certificate_id, issued_at, expires_at, revoked_at, rate_limit_count) FROM stdin;
ccc522b9191f06ed63dc4e745a9068937d767981aff7c4c069380d53f330e696	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000101	749410fc-3ec4-484f-9d94-f49f5fd4d8bd	2026-09-13 04:17:39.336807+00	2026-12-12 04:17:39.336807+00	\N	0
9974f73b3cdf48e891cba7a586d325dbde1775762c16d98a7294f8dbc52577c1	e73e7029-da66-4659-9ac8-845f22b1f8a5	00000000-0000-4000-8000-000000000101	3e272eca-8f3b-49e4-8153-a42d27e5033e	2026-09-13 04:20:36.815286+00	2026-12-12 04:20:36.815286+00	\N	3
\.


--
-- Name: events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_seq_seq', 145, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: brokerages brokerages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brokerages
    ADD CONSTRAINT brokerages_pkey PRIMARY KEY (brokerage_id);


--
-- Name: brokerages brokerages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brokerages
    ADD CONSTRAINT brokerages_slug_key UNIQUE (slug);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (client_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (event_id);


--
-- Name: magic_link_tokens magic_link_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.magic_link_tokens
    ADD CONSTRAINT magic_link_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: policies policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_pkey PRIMARY KEY (policy_id);


--
-- Name: proj_active_blocks proj_active_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_active_blocks
    ADD CONSTRAINT proj_active_blocks_pkey PRIMARY KEY (tenant_id, block_id);


--
-- Name: proj_class_unlock proj_class_unlock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_class_unlock
    ADD CONSTRAINT proj_class_unlock_pkey PRIMARY KEY (tenant_id, class_key);


--
-- Name: proj_kpi_daily proj_kpi_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_kpi_daily
    ADD CONSTRAINT proj_kpi_daily_pkey PRIMARY KEY (tenant_id, day, kpi_id);


--
-- Name: proj_matters proj_matters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_matters
    ADD CONSTRAINT proj_matters_pkey PRIMARY KEY (tenant_id, matter_id);


--
-- Name: proj_queue proj_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_queue
    ADD CONSTRAINT proj_queue_pkey PRIMARY KEY (tenant_id, envelope_id);


--
-- Name: proj_sprint_usage_by_agent proj_sprint_usage_by_agent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_sprint_usage_by_agent
    ADD CONSTRAINT proj_sprint_usage_by_agent_pkey PRIMARY KEY (tenant_id, agent_name);


--
-- Name: proj_sprint_usage proj_sprint_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_sprint_usage
    ADD CONSTRAINT proj_sprint_usage_pkey PRIMARY KEY (tenant_id);


--
-- Name: proj_workflow_waits proj_workflow_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_workflow_waits
    ADD CONSTRAINT proj_workflow_waits_pkey PRIMARY KEY (tenant_id, workflow_id, step);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (session_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (tenant_id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: user_brokerage_roles user_brokerage_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_brokerage_roles
    ADD CONSTRAINT user_brokerage_roles_pkey PRIMARY KEY (user_id, brokerage_id, role);


--
-- Name: user_client_links user_client_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client_links
    ADD CONSTRAINT user_client_links_pkey PRIMARY KEY (user_id, tenant_id, client_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: verifier_tokens verifier_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verifier_tokens
    ADD CONSTRAINT verifier_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: events_tenant_idempotency; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX events_tenant_idempotency ON public.events USING btree (tenant_id, idempotency_key);


--
-- Name: events_tenant_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_tenant_seq ON public.events USING btree (tenant_id, seq);


--
-- Name: events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_type ON public.events USING btree (type);


--
-- Name: magic_link_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX magic_link_user_idx ON public.magic_link_tokens USING btree (user_id) WHERE (used_at IS NULL);


--
-- Name: policies_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX policies_client_idx ON public.policies USING btree (tenant_id, client_id);


--
-- Name: proj_active_blocks_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX proj_active_blocks_target_idx ON public.proj_active_blocks USING btree (tenant_id, target_kind, target_id) WHERE (cleared_at IS NULL);


--
-- Name: proj_kpi_daily_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX proj_kpi_daily_recent ON public.proj_kpi_daily USING btree (tenant_id, kpi_id, day DESC);


--
-- Name: proj_queue_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX proj_queue_pending_idx ON public.proj_queue USING btree (tenant_id, sla_deadline) WHERE (resolved_at IS NULL);


--
-- Name: proj_sprint_usage_by_agent_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX proj_sprint_usage_by_agent_last_seen ON public.proj_sprint_usage_by_agent USING btree (tenant_id, last_seen DESC);


--
-- Name: proj_workflow_waits_fire_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX proj_workflow_waits_fire_at ON public.proj_workflow_waits USING btree (fire_at) WHERE (NOT resolved);


--
-- Name: sessions_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_idx ON public.sessions USING btree (user_id) WHERE (revoked_at IS NULL);


--
-- Name: verifier_tokens_policy_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX verifier_tokens_policy_idx ON public.verifier_tokens USING btree (tenant_id, policy_id);


--
-- Name: events events_no_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER events_no_delete BEFORE DELETE ON public.events FOR EACH ROW EXECUTE FUNCTION public.events_deny_mutation();


--
-- Name: events events_no_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER events_no_update BEFORE UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.events_deny_mutation();


--
-- Name: tenants tenants_immutable_genesis_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenants_immutable_genesis_trg BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.tenants_immutable_genesis();


--
-- Name: brokerages brokerages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brokerages
    ADD CONSTRAINT brokerages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: clients clients_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: events events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: magic_link_tokens magic_link_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.magic_link_tokens
    ADD CONSTRAINT magic_link_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: policies policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: proj_active_blocks proj_active_blocks_added_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_active_blocks
    ADD CONSTRAINT proj_active_blocks_added_by_event_fkey FOREIGN KEY (added_by_event) REFERENCES public.events(event_id);


--
-- Name: proj_active_blocks proj_active_blocks_cleared_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_active_blocks
    ADD CONSTRAINT proj_active_blocks_cleared_by_event_fkey FOREIGN KEY (cleared_by_event) REFERENCES public.events(event_id);


--
-- Name: proj_class_unlock proj_class_unlock_updated_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_class_unlock
    ADD CONSTRAINT proj_class_unlock_updated_by_event_fkey FOREIGN KEY (updated_by_event) REFERENCES public.events(event_id);


--
-- Name: proj_matters proj_matters_updated_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_matters
    ADD CONSTRAINT proj_matters_updated_by_event_fkey FOREIGN KEY (updated_by_event) REFERENCES public.events(event_id);


--
-- Name: proj_queue proj_queue_proposal_ref_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_queue
    ADD CONSTRAINT proj_queue_proposal_ref_fkey FOREIGN KEY (proposal_ref) REFERENCES public.events(event_id);


--
-- Name: proj_queue proj_queue_resolved_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_queue
    ADD CONSTRAINT proj_queue_resolved_by_event_fkey FOREIGN KEY (resolved_by_event) REFERENCES public.events(event_id);


--
-- Name: proj_sprint_usage proj_sprint_usage_updated_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_sprint_usage
    ADD CONSTRAINT proj_sprint_usage_updated_by_event_fkey FOREIGN KEY (updated_by_event) REFERENCES public.events(event_id);


--
-- Name: proj_workflow_waits proj_workflow_waits_updated_by_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proj_workflow_waits
    ADD CONSTRAINT proj_workflow_waits_updated_by_event_fkey FOREIGN KEY (updated_by_event) REFERENCES public.events(event_id);


--
-- Name: sessions sessions_brokerage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_brokerage_id_fkey FOREIGN KEY (brokerage_id) REFERENCES public.brokerages(brokerage_id);


--
-- Name: sessions sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: user_brokerage_roles user_brokerage_roles_brokerage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_brokerage_roles
    ADD CONSTRAINT user_brokerage_roles_brokerage_id_fkey FOREIGN KEY (brokerage_id) REFERENCES public.brokerages(brokerage_id);


--
-- Name: user_brokerage_roles user_brokerage_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_brokerage_roles
    ADD CONSTRAINT user_brokerage_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: user_client_links user_client_links_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client_links
    ADD CONSTRAINT user_client_links_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: user_client_links user_client_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client_links
    ADD CONSTRAINT user_client_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: verifier_tokens verifier_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verifier_tokens
    ADD CONSTRAINT verifier_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: clients clients_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clients_tenant_isolation ON public.clients USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

--
-- Name: events events_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY events_tenant_isolation ON public.events USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.policies ENABLE ROW LEVEL SECURITY;

--
-- Name: policies policies_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY policies_tenant_isolation ON public.policies USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_active_blocks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_active_blocks ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_active_blocks proj_active_blocks_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_active_blocks_tenant_isolation ON public.proj_active_blocks USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_class_unlock; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_class_unlock ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_class_unlock proj_class_unlock_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_class_unlock_tenant_isolation ON public.proj_class_unlock USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_kpi_daily; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_kpi_daily ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_kpi_daily proj_kpi_daily_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_kpi_daily_tenant_isolation ON public.proj_kpi_daily USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_matters; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_matters ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_matters proj_matters_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_matters_tenant_isolation ON public.proj_matters USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_queue; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_queue ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_queue proj_queue_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_queue_tenant_isolation ON public.proj_queue USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_sprint_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_sprint_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_sprint_usage_by_agent; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_sprint_usage_by_agent ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_sprint_usage_by_agent proj_sprint_usage_by_agent_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_sprint_usage_by_agent_tenant_isolation ON public.proj_sprint_usage_by_agent USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_sprint_usage proj_sprint_usage_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_sprint_usage_tenant_isolation ON public.proj_sprint_usage USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: proj_workflow_waits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proj_workflow_waits ENABLE ROW LEVEL SECURITY;

--
-- Name: proj_workflow_waits proj_workflow_waits_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY proj_workflow_waits_tenant_isolation ON public.proj_workflow_waits USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: verifier_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.verifier_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: verifier_tokens verifier_tokens_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY verifier_tokens_tenant_isolation ON public.verifier_tokens USING (
CASE
    WHEN ((current_setting('app.tenant_id'::text, true) IS NULL) OR (current_setting('app.tenant_id'::text, true) = ''::text)) THEN true
    ELSE (tenant_id = (current_setting('app.tenant_id'::text, true))::uuid)
END) WITH CHECK ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- PostgreSQL database dump complete
--

\unrestrict 2ghpCtAY1I2BBABEYsKGr1pUG19knfBHlFCIodlPlRb3XhSHqHpo10hW7ZN5WbC

