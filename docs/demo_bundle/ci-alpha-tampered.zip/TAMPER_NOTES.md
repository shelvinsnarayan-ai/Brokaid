# What was flipped

- Target event: seq #341 (index 10 of 21 events, chosen mid-chain).
- Field: `events[{idx}].payload_jcs` — one trailing ASCII space appended.
- Effect: the recomputed `payload_jcs` from `payload` no longer matches the stored value, so verify.js exits 1 with `FAIL — event #341` at the payload_jcs comparison before it even gets to hash re-computation.
- Why one space, not one bit-flip: keeps the change obvious to any auditor cracking open the zip; the failure is still a genuine chain-integrity break.
