# brokAId ledger export bundle

**Filename**: `ci-alpha-tampered.zip`
**Scope**: ci-alpha (fictional CI tenant) — TAMPERED
**Events in bundle**: 21
**Bundled verifier SHA-256**: `61dcfa317cd60e033a35b8f3036dcaaeba139f367fb2e7c6e68c6256283d8758`

This zip lets you verify the ledger's integrity **without** contacting
our servers or trusting any code we control at verification time.

## How to run

```
unzip ci-alpha-tampered.zip
cd $(basename ci-alpha-tampered.zip .zip)
node --version   # v18+
npm i canonicalize
node verify.js export.json
```
