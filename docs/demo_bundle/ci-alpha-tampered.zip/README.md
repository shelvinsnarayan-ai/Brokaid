# brokAId ledger export bundle

**Filename**: `ci-alpha-tampered.zip`
**Scope**: ci-alpha (fictional CI tenant) — TAMPERED
**Events in bundle**: 21
**Bundled verifier SHA-256**: `61dcfa317cd60e033a35b8f3036dcaaeba139f367fb2e7c6e68c6256283d8758`

This zip lets you verify the ledger's integrity **without** contacting
our servers or trusting any code we control at verification time. The
only dependencies are Node.js 18+ and the `canonicalize` npm package.

## How to run

```
unzip ci-alpha-tampered.zip
cd $(basename ci-alpha-tampered.zip .zip)
node --version   # must be v18 or newer
npm i canonicalize
node verify.js export.json
```

## What the output means

* `OK — <n> events verified` — every event's hash was recomputed from
  its raw fields and matches; every `prev_hash` points at the previous
  event in seq order; the genesis chain root matches the tenant's
  recorded `genesis_hash`. The exported ledger is intact.
* `FAIL — event #<seq>` — that event's recomputed hash did not match
  its recorded `event_hash`, OR its `prev_hash` did not point at the
  previous event. The bundle has been tampered with.

## Bundled verifier

`verify.js` is byte-identical to the copy in the brokAId repo at
`packages/kernel/verifier/verify.js`; `verifier_binary_sha256.txt`
records its SHA-256 so you can prove no substitution has happened
between build and download. The same digest appears inside
`export.json` under `verifier_binary_sha256`.

## Bundle contents

```
export.json                    - the ledger export (JCS-canonical fields)
verify.js                      - offline verifier (Node 18+)
verifier_binary_sha256.txt     - SHA-256 of verify.js
README.md                      - this file
```
